import React from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';
import ROUTE_PATH from '../constants/route_path_constants.json';
import * as page from '../../components/index';
import Login from '../../components/Login/Login';
import { combinedRoute } from '../../util/Utils';
import store from '../../app_store/store';

const loginPath = combinedRoute(ROUTE_PATH.pre_admin_route, ROUTE_PATH.login);

export const AppRoutes = () => {
    return (
        <Switch>
            <Route exact path={ROUTE_PATH.home} component={page.Home} />
            <Route exact path={ROUTE_PATH.aboutUs} component={page.AboutUs} />
            <Route exact path={ROUTE_PATH.enquiry} component={page.Enquiry} />
            <Route exact path={ROUTE_PATH.vacancyTraining} component={page.VacancyTraining} />
            <Route exact path={loginPath} component={Login}/>

            {/* <Route exact path={combinedRoute(ROUTE_PATH.pre_admin_route, ROUTE_PATH.enquiry)} component={} /> // check with roles
                <Route exact path={combinedRoute(ROUTE_PATH.pre_admin_route, ROUTE_PATH.vacancyTraining)} component={} /> */}

            <Redirect from={ROUTE_PATH.all} to={ROUTE_PATH.home} component={page.Home} />
        </Switch>
    );
}

const AuthRoute = props => {
    const { routePath, displayComponent } = props;

    return (
        <Route exact path={routePath} render={() => (store.getState().accessToken.length === 0 ? <Redirect to={loginPath} /> : displayComponent)} />
    );
}

export const ConfidentialRoutes = () => {
    return (
        <Switch>
            <AuthRoute routePath={combinedRoute(ROUTE_PATH.pre_admin_route, ROUTE_PATH.dashboard)} displayComponent={<page.Dashboard />} />
        </Switch>
    );
}

