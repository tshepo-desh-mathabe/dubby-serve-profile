const roles = [
    'ROLE_ADMIN',
    'ROLE_MENTOR',
    'ROLE_RECEPTION',
    'ROLE_RECRUITER',
    'ROLE_DEFAULT'
];

function checkRol(params) {
    
}