import data from '../../gobal/constants/app_state_constant.json';

export const storeUserDetails = (content) => ({
    type: data.loggedInUser,
    payload: content
});

export const clearUserDetails = () => ({
    type: data.clearLoggedInUser
});