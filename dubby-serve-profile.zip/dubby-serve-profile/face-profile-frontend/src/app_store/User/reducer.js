import data from '../../gobal/constants/app_state_constant.json';

const initialState = {
    fullName: '',
    roles: [],
    accessToken: ''
}

const userReducer = (state = initialState, action) => {
    // console.log('Action -->>', action);
    switch (action.type) {
        case data.loggedInUser:
            return {
                ...state,
                fullName: action.payload.fullName,
                roles: action.payload.roles,
                accessToken: action.payload.accessToken,

            }
            case data.clearLoggedInUser:
                return {
                    ...state,
                    fullName: initialState.fullName,
                    roles: initialState.roles,
                    accessToken: initialState.accessToken,
    
                }
        default:
            return state;
    }
};

export default userReducer;