import { useState, useEffect } from 'react';
import store from '../app_store/store';
import APP_CONST from '../gobal/constants/app_contants.json';

function getDimensions() {
  const { innerWidth: width, innerHeight: height } = window;
  return {
    width, height
  };
}

function WindowDimensions() {
  const [windowDimensions, setWindowDimensions] = useState(getDimensions());

  useEffect(() => {
    function handleResize() {
      setWindowDimensions(getDimensions());
    }

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return windowDimensions;
}

export default function isMobileByWidth() {
  if (store.getState().accessToken.length === 0 && WindowDimensions().width <= APP_CONST.numberFormat.mobileScreenSize) {
    return true;
  }
  // else if (WindowDimensions().width <= APP_CONST.numberFormat.mobileScreenSize) {
  //   return true;
  // }
  return false
}
