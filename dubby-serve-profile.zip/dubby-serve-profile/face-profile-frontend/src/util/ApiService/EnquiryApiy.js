import * as api from './api_constants';
import { httpRequest } from './util/Request';

export function saveEnquiry(requestBody) {
    return httpRequest(api.HTTP_REQUEST_TYPE.POST, api.SAVE_ENQUIRY, requestBody);
}
