import axios from 'axios';
import { HTTP_REQUEST_TYPE } from '../api_constants';

export const httpRequest = async (requestType, url, requestBody) => {

    const headers = new Headers({});
    // const defaults = { headers: headers };
    // options = Object.assign({}, defaults, options);

    switch (requestType) {
        case HTTP_REQUEST_TYPE.GET:
            return await axios.get(url, headers)
                .then(res => { return res; })
                .catch(err => { return Promise.reject(err); });

        case HTTP_REQUEST_TYPE.POST:
            return await axios.post(url, requestBody, headers)
                .then(res => { return res; })
                .catch(err => { return Promise.reject(err); });

        case HTTP_REQUEST_TYPE.PUT:
            return await axios.put(url, requestBody, headers)
                .then(res => { return res; })
                .catch(err => { return Promise.reject(err); });

        case HTTP_REQUEST_TYPE.DELETE:
            return await axios.delete(url, requestBody, headers)
                .then(res => { return res; })
                .catch(err => { return Promise.reject(err); });
        default:
            break;
    }
}
