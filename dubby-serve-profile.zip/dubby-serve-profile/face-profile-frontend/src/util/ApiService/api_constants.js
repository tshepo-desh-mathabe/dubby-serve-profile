export const API_BASE_URL_ACCOUNT = 'http://localhost:9095';

export const HTTP_REQUEST_TYPE = {
    GET: 'GET',
    POST: 'POST',
    PUT: 'PUT',
    DELETE: 'DELETE'
}

export const ENQUIRY_ENTRY_POINT = '/enquiry';
export const VACANCY_ENTRY_POINT = '/vacancy';
export const USER_ENTRY_POINT = '/user';


export const USER_LOGIN = `${API_BASE_URL_ACCOUNT}${USER_ENTRY_POINT}/sign-in`;
export const GET_USER_LOGGED_IN = `${API_BASE_URL_ACCOUNT}${USER_ENTRY_POINT}/current-logged`;
export const USER_LOGOUT = `${API_BASE_URL_ACCOUNT}${USER_ENTRY_POINT}/log-out`;

export const SAVE_ENQUIRY = `${API_BASE_URL_ACCOUNT}${ENQUIRY_ENTRY_POINT}/save`;
export const SAVE_VACANCY = `${API_BASE_URL_ACCOUNT}${VACANCY_ENTRY_POINT}/save`;



