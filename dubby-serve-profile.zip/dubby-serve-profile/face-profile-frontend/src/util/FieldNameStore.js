let fieldData = null;

class FieldNameStore {
    constructor() {
        fieldData = [];

        if (!FieldNameStore.fieldStore) {
            FieldNameStore.fieldStore = this
        }
        // Initialize object
        return FieldNameStore.fieldStore
    }

    setFieldNames(value) {
        fieldData.push(value);

        fieldData.reverse();
        const result = fieldData.reduce((unique, data) => {
            if (!unique.some(obj => obj.fieldName === data.fieldName && obj.fieldLenght !== data.fieldLenght)) {
                unique.push(data);
            }
            return unique;
        }, []);


        fieldData = result;
        fieldData = fieldData.filter(e => e.fieldLenght !== 0);
    }

    getFieldNames() {
        return fieldData;
    }
}

const fieldStore = new FieldNameStore()
Object.freeze(fieldStore)

export default fieldStore;
