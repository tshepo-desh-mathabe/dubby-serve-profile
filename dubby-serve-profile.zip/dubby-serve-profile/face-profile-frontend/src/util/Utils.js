export function combinedRoute(prePath, postPath) {
    return `${prePath}${postPath}`;
}
