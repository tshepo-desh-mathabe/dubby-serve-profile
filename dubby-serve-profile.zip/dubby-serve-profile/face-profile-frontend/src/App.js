import React from 'react';
import { Router } from 'react-router-dom';
import { connect } from 'react-redux';
import STORE_CONST from './gobal/constants/app_state_constant.json';
import history from './util/BrowserHistory';
import AppRender from './AppRender/AppRender';
import './App.scss';

function App() {
  return (
    <Router history={history}>
      <AppRender />
    </Router>
  );
  
}
const mapDispacthToProps = (dispatch) => {
  return {
    userData: (httpResponse) => dispatch({ type: STORE_CONST.loggedInUser, payload: httpResponse })
  }
}

export default connect(null, mapDispacthToProps)(App);
