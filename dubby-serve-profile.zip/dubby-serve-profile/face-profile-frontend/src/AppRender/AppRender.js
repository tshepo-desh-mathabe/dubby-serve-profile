import React, { Fragment } from 'react';
import history from '../util/BrowserHistory';
import { Footer } from '../components/Footer';
import { AppRoutes, ConfidentialRoutes } from '../gobal/routes/AppRoutes';
import NavigationBar from '../components/NavBar/Navigationbar';
import ROUTE_PATH from '../gobal/constants/route_path_constants.json';

const AppRender = () => {
    if (history.location.pathname.includes(`${ROUTE_PATH.pre_admin_route}`)) {
        return (
            <Fragment>
                <NavigationBar>
                    <ConfidentialRoutes />
                </NavigationBar>
                <Footer />
            </Fragment>
        );
    }

    return (
        <Fragment>
            <NavigationBar>
                <AppRoutes />
            </NavigationBar>
            <Footer />
        </Fragment>
    );
}

export default AppRender;