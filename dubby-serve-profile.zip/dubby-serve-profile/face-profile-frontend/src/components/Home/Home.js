import React, { Fragment } from 'react';
import { Message, Icon, Grid, List, Divider, Segment, Header } from 'semantic-ui-react';
import DisplayWrapper from '../util/DisplayWrapper';
import APP_CONST from '../../gobal/constants/app_contants.json';
import './Home.scss';

const BootstrapWrapper = props => {
    const { content, imageName } = props;
    return (
        <Message color='brown'>
            <Message.Header>
                <Divider horizontal>
                    <Header>
                        <div className='icon-image'>
                            <Icon name={imageName} size='huge' />
                        </div>
                    </Header>
                </Divider>
                {content}
            </Message.Header>
        </Message>
    );
}

function Body() {
    return (
        <Fragment>
            <BootstrapWrapper swapFlag={false} imageName='info' content={
                <div className='intro-body'>
                    <p>{APP_CONST.infoContent.data1}</p>
                    <p>{APP_CONST.infoContent.data2}</p>
                    <p>{APP_CONST.infoContent.data3}</p>
                </div>
            } />

            <BootstrapWrapper swapFlag={true} imageName='certificate' content={
                <div className='second-body'>
                    <p>{APP_CONST.infoContent.data4}</p>
                    <p>{APP_CONST.infoContent.data5}</p>
                    <p>{APP_CONST.infoContent.data6}</p>
                </div>
            } />

            <BootstrapWrapper swapFlag={false} imageName='connectdevelop' content={
                <div className='third-body'>
                    <p>{APP_CONST.infoContent.data7}</p>
                    <p>{APP_CONST.infoContent.data8}</p>
                </div>
            } />
            <br />
            <div className='extra-content'>
                <Header as='h2'>
                    <div className='header'>{APP_CONST.infoContent.whatWeDo}</div>
                </Header>
                <Segment>
                    <Grid columns={2}>
                        <Grid.Column>
                            <List>
                                <List.Item icon='code' content={APP_CONST.infoContent.data9} />
                                <List.Item icon='code' content={APP_CONST.infoContent.data10} />
                                <List.Item icon='code' content={APP_CONST.infoContent.data11} />
                                <List.Item icon='code' content={APP_CONST.infoContent.data12} />
                            </List>
                        </Grid.Column>
                        <Grid.Column>
                            <List>
                                <List.Item icon='code' content={APP_CONST.infoContent.data13} />
                                <List.Item icon='code' content={APP_CONST.infoContent.data14} />
                                <List.Item icon='code' content={APP_CONST.infoContent.data15} />
                            </List>
                        </Grid.Column>
                    </Grid>
                </Segment>
            </div>
            <br />
        </Fragment>
    );
}


export const Home = () => {
    return (
        <DisplayWrapper header={false} body={<Body />} footer={false} />
    );
}
