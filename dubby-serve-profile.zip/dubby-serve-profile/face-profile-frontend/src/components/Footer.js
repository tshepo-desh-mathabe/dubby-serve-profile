import APP_CONST from '../gobal/constants/app_contants.json';

export const Footer = () => {
    return (
        <footer style={{
            position: 'fixed',
            bottom: '0',
            left: '0',
            right: '0',
            textAlign: 'center',
            padding: '12px',
            zIndex: 1
        }}>
            <p><b>&copy; {APP_CONST.allRightsReserved}</b></p>
        </footer>
    )
}