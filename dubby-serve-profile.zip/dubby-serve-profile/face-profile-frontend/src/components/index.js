export { Home } from './Home/Home';
export { Enquiry } from './Enquiry/Enquiry';
export { VacancyTraining } from './VacancyTraining/VacancyTraining';
export { AboutUs } from './AboutUs';
export {Dashboard } from './Dashboard/Dashoard'
// export { Login } from './Login/Login';
