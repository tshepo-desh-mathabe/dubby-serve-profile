import React from 'react';
import { Header, Grid, Icon } from 'semantic-ui-react';
import DisplayWrapper from './util/DisplayWrapper';
import app_const from '../gobal/constants/app_contants.json';
import { ListPopulator } from './util/ListPopulator';

const whoWeAreData = app_const.aboutUsContent.whoWeAreContent;
const whyDubby = app_const.aboutUsContent.whyDubbyServeContent;
const weAreContent = app_const.aboutUsContent.weAreContent;
const techStackData = app_const.aboutUsContent.techStackContent;

const RenderGridColums = props => {
    const { headerName, icon, content } = props;

    return (
        <Grid.Column>
            <Header icon>
                <Icon name={icon} />
                {headerName}
            </Header>
            <ListPopulator iconName={icon} data={content} />
        </Grid.Column>
    );
}

export const AboutUs = () => {
    return (
        <DisplayWrapper body={
            <React.Fragment>
                <Header as='h2' content={app_const.aboutUsContent.whoWeAre} />
                <p>
                    {whoWeAreData.intro}
                    {whoWeAreData.ourGoal}
                    {whoWeAreData.prideInDev}
                    {whoWeAreData.notLimited}
                    {whoWeAreData.modernDev}
                    {whoWeAreData.weAgil}
                </p>

                <Header as='h2' content={app_const.aboutUsContent.whyDubbyServe} />
                <p>
                    {whyDubby.notAffordDeveloper}
                    {whyDubby.smallTimeAssist}
                    {whyDubby.issueWeConsider}
                    {whyDubby.devSmallGrowing}
                    {whyDubby.solutionsWeProvide}
                </p>

                <Header as='h2' content={app_const.aboutUsContent.weAre} />
                <ListPopulator iconName='leaf' data={weAreContent} />

                <Header as='h2' content={app_const.aboutUsContent.techStack} />
                <Grid columns={4} stackable>
                    <Grid.Row>
                        <RenderGridColums headerName={techStackData.frontend} icon='laptop' content={techStackData.frontentContent} />
                        <RenderGridColums headerName={techStackData.mobile} icon='mobile alternate' content={techStackData.mobileContent} />
                        <RenderGridColums headerName={techStackData.desktop} icon='desktop' content={techStackData.desktopContent} />
                        <RenderGridColums headerName={techStackData.backend} icon='coffee' content={techStackData.backendContent} />
                    </Grid.Row>
                    <Grid.Row>
                        <RenderGridColums headerName={techStackData.cloud} icon='cloud' content={techStackData.cloudContent} />
                        <RenderGridColums headerName={techStackData.devOps} icon='connectdevelop' content={techStackData.devOpsContent} />
                        <RenderGridColums headerName={techStackData.database} icon='database' content={techStackData.databaseContent} />
                        <RenderGridColums headerName={techStackData.sourceControl} icon='git' content={techStackData.sourceControlContent} />
                    </Grid.Row>
                </Grid>
            </React.Fragment>
        } />
    );
}