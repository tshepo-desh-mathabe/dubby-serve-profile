import { List } from 'semantic-ui-react';

export const ListPopulator = props => {
    const { iconName, data } = props;
    return (
        <List>
            {
                data.map((e, index) => (<List.Item key={index} icon={iconName} content={e.value} />))
            }
        </List>
    );
}
