import isMobileByWidth from '../../util/ScreenSizeDetection';

const DisplayWrapper = props => {
    const { body } = props;

    return (
        <>
            {
                isMobileByWidth() ?
                    <div className='mobile-body-content'>{body}</div> :
                    <div className='desktop-body-content'>{body}</div>
            }
        </>
    );
}

export default DisplayWrapper;
