import React from 'react';
import { Form, Dropdown, Label, Input } from 'semantic-ui-react';
import { validateEmptyFields } from '../../util/Validators';
import code_const from '../../gobal/constants/country_code.json';
import app_const from '../../gobal/constants/app_contants.json';

const stateOptions = code_const.map((state, index) => ({
    key: index,
    text: state.name,
    value: state.code,
}));

const formData = app_const.formContent;

const CountryCodeComponent = props => {
    const { handleChange, countryCode, phoneNumber, sendingFlag } = props;
    
    return (
        <React.Fragment>
            <Form.Field
                control={Dropdown}
                label={formData.label.countryCode}
                placeholder={formData.placeHolderContent.whatCountry}
                name='countryCode'
                search
                selection
                options={stateOptions}
                value={countryCode}
                onChange={handleChange}
                error={validateEmptyFields(sendingFlag, countryCode) && {
                    content: formData.errorContent.countryCode
                }}
            />
            <Form.Field>
                <label htmlFor='formFileMultiple' className='form-label'>{formData.label.phoneNumber}</label>
                <Input
                    label={{ basic: true, content: countryCode }}
                    placeholder={formData.placeHolderContent.yourPhoneNumber}
                    name='phoneNumber'
                    type='number'
                    value={phoneNumber}
                    onChange={handleChange}
                    disabled={countryCode === null}
                />
                {
                    validateEmptyFields(sendingFlag, phoneNumber) ? <Label pointing content={formData.errorContent.phoneNumber} /> : null
                }
            </Form.Field>
        </React.Fragment>
    );
}

export default CountryCodeComponent;