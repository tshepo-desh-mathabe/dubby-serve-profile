import React, { Fragment } from 'react';
import { Form, Input, TextArea } from 'semantic-ui-react';
import app_const from '../../gobal/constants/app_contants.json';
import { validateEmptyFields, validateEmail } from '../../util/Validators';
import CountryCodeComponent from '../util/CountryCodeComponent';

const placeholderData = app_const.formContent.placeHolderContent;
const formLabel = app_const.formContent.label;
const errorData = app_const.formContent.errorContent;

const EnquiryForm = props => {
    const {
        sendingFlag, firstName, lastName, emailAddress, phoneNumber,
        messageBody, handleChange, countryCode, messageSubject
    } = props;

    return (
        <Fragment>
            <Form.Group widths='equal'>
                <Form.Field
                    control={Input}
                    label={formLabel.firstName}
                    placeholder={placeholderData.data1}
                    name='firstName'
                    value={firstName}
                    onChange={handleChange}
                    error={validateEmptyFields(sendingFlag, firstName) && {
                        content: errorData.firstName
                    }}
                />
                <Form.Field
                    control={Input}
                    label={formLabel.lastName}
                    placeholder={placeholderData.data2}
                    name='lastName'
                    value={lastName}
                    onChange={handleChange}
                    error={validateEmptyFields(sendingFlag, lastName) && {
                        content: errorData.lastName
                    }}
                />
            </Form.Group>

            <Form.Group widths='equal'>
                <Form.Field
                    control={Input}
                    label={formLabel.emailAddress}
                    placeholder={placeholderData.data3}
                    name='emailAddress'
                    value={emailAddress}
                    onChange={handleChange}
                    error={validateEmail(sendingFlag, emailAddress) && {
                        content: errorData.emailAddress
                    }}
                />
                <CountryCodeComponent handleChange={handleChange}
                    countryCode={countryCode} sendingFlag={sendingFlag} phoneNumber={phoneNumber} />
            </Form.Group>

            <Form.Field
                width={11}
                control={Input}
                label={formLabel.messageSubject}
                placeholder={placeholderData.messageSubject}
                name='messageSubject'
                value={messageSubject}
                onChange={handleChange}
                error={validateEmptyFields(sendingFlag, messageSubject) && {
                    content: errorData.messageSubject
                }}
            />

            <Form.Field>
                <Form.Field
                    control={TextArea}
                    label={`${formLabel.messageComment}     [${1000 - messageBody.length}]`}
                    placeholder={placeholderData.message}
                    name='messageBody'
                    value={messageBody}
                    onChange={handleChange}
                    error={validateEmptyFields(sendingFlag, messageBody) && {
                        content: errorData.messageBody
                    }}
                />
            </Form.Field>
        </Fragment>
    );
}

export default EnquiryForm;