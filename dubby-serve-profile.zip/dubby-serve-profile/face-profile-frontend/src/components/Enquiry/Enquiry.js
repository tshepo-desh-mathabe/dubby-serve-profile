import React, { Component } from 'react';
import DisplayWrapper from '../util/DisplayWrapper';
import { DisplayFormWrapper } from '../util/DisplayFormWrapper';
import PageLoader from '../PageLoader/PageLoader';
import AppMessage from '../../message/AppMessage';
import EnquiryForm from './EnquiryForm';
import app_const from '../../gobal/constants/app_contants.json';
import { dataChecker, emailRegex } from '../../util/Validators';
import { saveEnquiry } from '../../util/ApiService/EnquiryApiy';

const initialState = {
    showLoader: { flag: false, content: '' },
    showMessage: {
        flag: false,
        icon: '',
        topic: '',
        content: ''
    },
    sendingFlag: false,
    firstName: '',
    lastName: '',
    phoneNumber: '',
    emailAddress: '',
    messageSubject: '',
    messageBody: '',
    countryCode: null,
    isRead: false,
    isDelete: false
};

export class Enquiry extends Component {

    constructor(props) {
        super(props);

        this.state = initialState;

        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleModalClick = this.handleModalClick.bind(this);
    }

    handleChange = (e, { name, value }) => {
        if (this.state.sendingFlag) {
            this.setState({ [name]: value, sendingFlag: false });
        } else {
            this.setState({ [name]: value });
        }
    }

    handleModalClick() {
        this.setState({ showMessage: { flag: false, content: '' } });
    }

    fieldChecker() {
        const state = this.state;

        const checker = dataChecker(state.firstName) && dataChecker(state.lastName) &&
            dataChecker(state.phoneNumber) && dataChecker(state.emailAddress) &&
            dataChecker(state.messageSubject) && dataChecker(state.messageBody) && dataChecker(state.countryCode);
        return checker;
    }

    handleSubmit() {
        const state = this.state;

        if (!this.fieldChecker()) {
            this.setState({
                sendingFlag: true,
                showMessage: {
                    flag: true, icon: 'edit',
                    topic: app_const.emptyFields, content: app_const.fillEmptyFields
                }
            });
        } else if (!emailRegex(state.emailAddress)) {
            this.setState({
                sendingFlag: true,
                showMessage: {
                    flag: true, icon: 'mail',
                    topic: app_const.formContent.errorContent.badEmail,
                    content: app_const.formContent.errorContent.emailAddress
                }
            });
        } else {
            this.httpCall(state);
        }
    }

    httpCall(state) {
        if (state.messageBody.length > 1000) {
            this.setState({
                sendingFlag: true,
                showMessage: {
                    flag: true, icon: 'exclamation triangle',
                    topic: app_const.oopsie,
                    content: app_const.formContent.errorContent.messageBodyLength1000
                }
            });
        } else {
            this.setState({
                sendingFlag: true,
                showLoader: { flag: true, content: app_const.pleaseWaitWhileCompletion }
            });

            const dataToBeSent = {
                name: state.firstName,
                surname: state.lastName,
                messageSubject: state.messageSubject,
                messageBody: state.messageBody,
                contactDetailsDetails: {
                    phoneNumberDetails: {
                        number: state.phoneNumber,
                        countryCodeDetails: { code: state.countryCode }
                    },
                    emailAddressDetails: { emailAddress: state.emailAddress }
                },
                isRead: state.isRead,
                isDelete: state.isDelete
            }

            saveEnquiry(dataToBeSent).then(res => {
                const resData = res.data;
                if (!resData.success) {
                    this.setState({
                        showMessage: {
                            flag: true, icon: 'exclamation triangle',
                            topic: app_const.oopsie, content: resData.message
                        },
                        showLoader: { flag: false, content: '' }
                    });
                } else {
                    this.setState(initialState, {
                        showMessage: {
                            flag: true, icon: 'info',
                            topic: app_const.applied, content: resData.message
                        },
                        showLoader: { flag: false, content: '' }
                    });
                }
            }).catch(err => {
                this.setState({
                    showLoader: { flag: false, content: '' },
                    showMessage: {
                        flag: true, icon: 'exclamation triangle',
                        topic: app_const.oopsie, content: app_const.defaultError
                    }
                });
            });
        }
    }

    DisplayElement = () => {
        const state = this.state;

        if (state.showMessage.flag) {
            return <AppMessage
                iconName={state.showMessage.icon}
                isOpen={state.showMessage.flag}
                headingInfo={state.showMessage.topic}
                message={state.showMessage.content}
                handleModalClick={this.handleModalClick}
            />;
        } else if (state.showLoader.flag) {
            return <PageLoader loaderInfo={state.showLoader.content} />;
        } else {
            return (
                <DisplayWrapper body={
                    <RenderForm sendingFlag={state.sendingFlag} firstName={state.firstName} lastName={state.lastName}
                        messageSubject={state.messageSubject} emailAddress={state.emailAddress} phoneNumber={state.phoneNumber}
                        messageBody={state.messageBody} countryCode={state.countryCode} handleChange={this.handleChange}
                        handleSubmit={this.handleSubmit}
                    />
                } />
            );
        }
    }

    render() {
        return <this.DisplayElement />
    }
}

const RenderForm = props => {
    const {
        sendingFlag, firstName, lastName, emailAddress, messageSubject,
        phoneNumber, messageBody, handleChange, handleSubmit, countryCode,
    } = props;

    return (
        <DisplayFormWrapper headerIcon='question circle outline' headerName={app_const.enquiryToKnow}
            formData={handleSubmit} buttonIcon='send' buttonName={app_const.submit} children={
                <EnquiryForm sendingFlag={sendingFlag} firstName={firstName} lastName={lastName}
                    messageSubject={messageSubject} emailAddress={emailAddress} phoneNumber={phoneNumber}
                    messageBody={messageBody} handleChange={handleChange} countryCode={countryCode}
                />
            } />
    );
}
