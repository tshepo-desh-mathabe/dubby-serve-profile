import React, { Fragment } from 'react';
import { Form, Input } from 'semantic-ui-react';
import app_const from '../../gobal/constants/app_contants.json';
import { validateEmptyFields, validateEmail } from '../../util/Validators';

const placeholderData = app_const.formContent.placeHolderContent;
const formLabel = app_const.formContent.label;
const errorData = app_const.formContent.errorContent;

export const LoginForm = props => {
    const { sendingFlag, emailAddress, password, handleChange } = props;

    return (
        <Fragment>
            <Form.Field
                control={Input}
                label={formLabel.emailAddress}
                placeholder={placeholderData.data3}
                name='emailAddress'
                value={emailAddress}
                onChange={handleChange}
                error={validateEmail(sendingFlag, emailAddress) && {
                    content: errorData.emailAddress
                }}
            />
            <Form.Field
                control={Input}
                type='password'
                label={formLabel.password}
                placeholder={placeholderData.passwordEnter}
                name='password'
                value={password}
                onChange={handleChange}
                error={validateEmptyFields(sendingFlag, password) && {
                    content: errorData.password
                }}
            />
        </Fragment>
    );
}