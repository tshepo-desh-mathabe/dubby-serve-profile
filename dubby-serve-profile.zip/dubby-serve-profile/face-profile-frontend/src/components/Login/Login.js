import React, { Component } from 'react';
import { Container } from 'semantic-ui-react';
import { Redirect } from 'react-router-dom';
import { LoginForm } from './LoginForm';
import { DisplayFormWrapper } from '../util/DisplayFormWrapper';
import DisplayWrapper from '../util/DisplayWrapper';
import { dataChecker, emailRegex } from '../../util/Validators';
import { signIn } from '../../util/ApiService/UserApi';
import AppMessage from '../../message/AppMessage';
import PageLoader from '../PageLoader/PageLoader';
import history from '../../util/BrowserHistory';
import app_const from '../../gobal/constants/app_contants.json';
import store_const from '../../gobal/constants/app_state_constant.json';
import ROUTE_PATH from '../../gobal/constants/route_path_constants.json';
import { connect } from 'react-redux';
import store from '../../app_store/store';
import * as page from '../../components/index';
import AppRender from '../../AppRender/AppRender';

const initialState = {
    showLoader: { flag: false, content: '' },
    showMessage: {
        flag: false,
        icon: '',
        topic: '',
        content: ''
    },
    sendingFlag: false,
    emailAddress: '',
    password: '',
};

class Login extends Component {
    constructor(props) {
        super(props);

        this.state = initialState;

        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleModalClick = this.handleModalClick.bind(this);
    }

    handleChange = (e, { name, value }) => {
        if (this.state.sendingFlag) {
            this.setState({ [name]: value, sendingFlag: false });
        } else {
            this.setState({ [name]: value });
        }
    }

    handleModalClick() {
        this.setState({ showMessage: { flag: false, content: '' } });
    }

    fieldChecker() {
        const state = this.state;
        const checker = dataChecker(state.emailAddress) && dataChecker(state.password);
        return checker;
    }

    handleSubmit() {
        const state = this.state;

        if (!this.fieldChecker()) {
            this.setState({
                sendingFlag: true,
                showMessage: {
                    flag: true, icon: 'edit',
                    topic: app_const.emptyFields, content: app_const.fillEmptyFields
                }
            });
        } else if (!emailRegex(state.emailAddress)) {
            this.setState({
                sendingFlag: true,
                showMessage: {
                    flag: true, icon: 'mail',
                    topic: app_const.formContent.errorContent.badEmail,
                    content: app_const.formContent.errorContent.emailAddress
                }
            });
        } else {
            this.httpCall(state);
        }
    }

    httpCall(state) {
        this.setState({
            sendingFlag: true,
            showLoader: { flag: true, content: app_const.pleaseWaitWhileCompletion }
        });

        const dataToBeSent = {
            emailAddressDetails: { emailAddress: state.emailAddress },
            password: state.password
        }

        // dummy data
        const reduxState = {
            fullName: 'Leo',
            roles: 'USER_ROLE',
            accessToken: 'jhjhkgjhgfghvjfgcj345y6yugvcxeryy54ctvytreyxc75r6tv7byti3456cfgvbjhr8c75e46rytuviyghj'
        }

        this.props.userData(reduxState);
        this.setState(initialState);
        history.push(`${ROUTE_PATH.pre_admin_route}${ROUTE_PATH.dashboard}`);

        // signIn(dataToBeSent).then(res => {
        //     const resData = res.data;
        //     if (!resData.success) {
        //         this.setState({
        //             showMessage: {
        //                 flag: true, icon: 'exclamation triangle',
        //                 topic: app_const.oopsie, content: resData.message
        //             },
        //             showLoader: { flag: false, content: '' }
        //         });
        //     } else {
        //         const data = resData.message;
        //         const reduxState = {
        //             fullName: `${data.name} ${data.surname}`,
        //             roles: data.roles,
        //             accessToken: data.accessToken
        //         }
        //     }
        // }).catch(err => {
        //     console.log('Error -->', err);
        //     this.setState({
        //         showLoader: { flag: false, content: '' },
        //         showMessage: {
        //             flag: true, icon: 'exclamation triangle',
        //             topic: app_const.oopsie, content: app_const.defaultError
        //         }
        //     });
        // });
    }

    DisplayElement = () => {
        const state = this.state;

        if (state.showMessage.flag) {
            return <AppMessage
                iconName={state.showMessage.icon}
                isOpen={state.showMessage.flag}
                headingInfo={state.showMessage.topic}
                message={state.showMessage.content}
                handleModalClick={this.handleModalClick}
            />;
        } else if (state.showLoader.flag) {
            return <PageLoader loaderInfo={state.showLoader.content} />;
        } else {
            return (
                <DisplayWrapper body={
                    <RenderForm sendingFlag={state.sendingFlag} emailAddress={state.emailAddress}
                        password={state.password} handleChange={this.handleChange} handleSubmit={this.handleSubmit} />
                } />
            );
        }
    }

    render() {
        // force re-render with "<AppRender />"
        return store.getState().accessToken.length !== 0 ? <AppRender /> : <this.DisplayElement /> 
    }
}

const RenderForm = props => {
    const { sendingFlag, emailAddress, password, handleChange, handleSubmit } = props
    return (
        <Container>
            <DisplayFormWrapper headerIcon='sign-in' headerName={app_const.signin}
                formData={handleSubmit} buttonIcon='sign-in' buttonName={app_const.signin}
                children={
                    <LoginForm sendingFlag={sendingFlag} emailAddress={emailAddress}
                        password={password} handleChange={handleChange} />
                }
            />
        </Container>
    );
}

const mapDispacthToProps = (dispatch) => {
    return {
        userData: (httpResponse) => dispatch({ type: store_const.loggedInUser, payload: httpResponse })
    }
}

export default connect(null, mapDispacthToProps)(Login);