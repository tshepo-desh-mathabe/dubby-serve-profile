import React, { Component } from 'react';
import DisplayWrapper from '../util/DisplayWrapper';
import { getFileByteArray } from '../../util/FileProcessor';
import { DisplayFormWrapper } from '../util/DisplayFormWrapper';
import VacancyTrainingForm from './VacancyTrainingForm';
import { saveVacancyTraining } from '../../util/ApiService/VacancyTrainingApi';
import PageLoader from '../PageLoader/PageLoader';
import AppMessage from '../../message/AppMessage';
import { dataChecker, emailRegex } from '../../util/Validators';
import app_const from '../../gobal/constants/app_contants.json';
import './VacancyTraining.scss';

const initialState = {
    showLoader: { flag: false, content: '' },
    showMessage: {
        flag: false,
        icon: '',
        topic: '',
        content: ''
    },
    sendingFlag: false,
    firstName: '',
    lastName: '',
    trainingVacancy: app_const.formContent.training,
    phoneNumber: '',
    emailAddress: '',
    documents: [{ fileId: null, fileData: [] }],
    messageBody: '',
    countryCode: null,
    isRead: false,
    isDelete: false
};

export class VacancyTraining extends Component {

    constructor(props) {
        super(props);
        this.state = initialState;
        this.handleModalClick = this.handleModalClick.bind(this);
    }

    handleChange = (e, { name, value }) => {
        if (name === 'training-vacancy') {
            if (this.state.sendingFlag) {
                this.setState({ trainingVacancy: value, sendingFlag: false });
            } else {
                this.setState({ trainingVacancy: value });
            }
        } else {
            if (this.state.sendingFlag) {
                this.setState({ [name]: value, sendingFlag: false });
            } else {
                this.setState({ [name]: value });
            }
        }
    }

    handleFilePicker = event => {
        this.setState({ showLoader: { flag: true, content: app_const.processingFiles } });
        const files = event.target.files;
        const data = [];

        for (let i = 0; i < files.length; i++) {
            getFileByteArray(files[i]).then(res => {
                data.push({ fileId: i, fileData: res });
            }).catch(err => {
                this.setState({
                    showMessage: { flag: true, content: app_const.defaultError },
                    showLoader: { flag: false, content: '' }
                });
            });
        }

        this.setState({
            documents: data,
            showLoader: { flag: false, content: '' }
        });
    }

    handleModalClick() {
        this.setState({ showMessage: { flag: false, content: '' } });
    }

    fieldChecker() {
        const state = this.state;
        const checker = dataChecker(state.firstName) && dataChecker(state.lastName) && dataChecker(state.phoneNumber) &&
            dataChecker(state.emailAddress) && dataChecker(state.documents[0].fileId) && dataChecker(state.countryCode);
        return checker;
    }

    handleSubmit = () => {
        const state = this.state;

        if (!this.fieldChecker()) {
            this.setState({
                sendingFlag: true,
                showMessage: {
                    flag: true, icon: 'edit',
                    topic: app_const.emptyFields, content: app_const.fillEmptyFields
                }
            });
        } else if (!emailRegex(state.emailAddress)) {
            this.setState({
                sendingFlag: true,
                showMessage: {
                    flag: true, icon: 'mail',
                    topic: app_const.formContent.errorContent.badEmail,
                    content: app_const.formContent.errorContent.emailAddress
                }
            });
        } else {
            this.httpCall(state);
        }
    }

    httpCall(state) {
        if (state.messageBody.length > 500) {
            this.setState({
                sendingFlag: true,
                showMessage: {
                    flag: true, icon: 'exclamation triangle',
                    topic: app_const.oopsie,
                    content: app_const.formContent.errorContent.messageBodyLength500
                }
            });
        } else {
            this.setState({
                sendingFlag: true,
                showLoader: { flag: true, content: app_const.pleaseWaitWhileCompletion }
            });

            const dataToBeSent = {
                name: state.firstName,
                surname: state.lastName,
                vacancyOptionDetails: { vacancyOption: state.trainingVacancy },
                messageBody: state.messageBody,
                contactDetailsDetails: {
                    phoneNumberDetails: {
                        number: state.phoneNumber,
                        countryCodeDetails: { code: state.countryCode }
                    },
                    emailAddressDetails: { emailAddress: state.emailAddress }
                },
                documents: state.documents,
                isRead: state.isRead,
                isDelete: state.isDelete
            }

            saveVacancyTraining(dataToBeSent).then(res => {
                const resData = res.data;
                if (!resData.success) {
                    this.setState({
                        showMessage: {
                            flag: true, icon: 'exclamation triangle',
                            topic: app_const.oopsie, content: resData.message
                        },
                        showLoader: { flag: false, content: '' }
                    });
                } else {
                    this.setState(initialState, {
                        showMessage: {
                            flag: true, icon: 'info',
                            topic: app_const.applied, content: resData.message
                        },
                        showLoader: { flag: false, content: '' }
                    });
                }
            }).catch(err => {
                this.setState({
                    showLoader: { flag: false, content: '' },
                    showMessage: {
                        flag: true, icon: 'exclamation triangle',
                        topic: app_const.oopsie, content: app_const.defaultError
                    }
                });
            });
        }
    }

    DisplayElement = () => {
        const state = this.state;

        if (state.showMessage.flag) {
            return <AppMessage
                iconName={state.showMessage.icon}
                isOpen={state.showMessage.flag}
                headingInfo={state.showMessage.topic}
                message={state.showMessage.content}
                handleModalClick={this.handleModalClick}
            />;
        } else if (state.showLoader.flag) {
            return <PageLoader loaderInfo={state.showLoader.content} />;
        } else {
            return (
                <DisplayWrapper body={
                    <RenderForm sendingFlag={state.sendingFlag} firstName={state.firstName} lastName={state.lastName}
                        trainingVacancy={state.trainingVacancy} emailAddress={state.emailAddress} phoneNumber={state.phoneNumber}
                        cvResume={state.cvResume} messageBody={state.messageBody} handleChange={this.handleChange}
                        handleFilePicker={this.handleFilePicker} handleSubmit={this.handleSubmit} countryCode={state.countryCode}
                    />
                } />
            );
        }
    }

    render() {
        return <this.DisplayElement />
    }
}

const RenderForm = props => {
    const {
        sendingFlag, firstName, lastName, trainingVacancy, emailAddress,
        phoneNumber, messageBody, handleChange, handleFilePicker, handleSubmit,
        countryCode
    } = props;

    return (
        <DisplayFormWrapper headerIcon='user' headerName={app_const.beOneOfUs}
            formData={handleSubmit} buttonIcon='send' buttonName={app_const.submit} children={
                <VacancyTrainingForm sendingFlag={sendingFlag} firstName={firstName} lastName={lastName}
                    trainingVacancy={trainingVacancy} emailAddress={emailAddress} phoneNumber={phoneNumber}
                    messageBody={messageBody} handleChange={handleChange} handleFilePicker={handleFilePicker}
                    countryCode={countryCode}
                />
            } />
    );
}
