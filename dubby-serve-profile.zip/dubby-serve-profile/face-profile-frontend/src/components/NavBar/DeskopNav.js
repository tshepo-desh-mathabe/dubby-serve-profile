import React from 'react';
import { Menu, Header } from 'semantic-ui-react';
import { MenuItems } from './MenuItems';
import { Link } from 'react-router-dom';
import store from '../../app_store/store';
import { combinedRoute } from '../../util/Utils';
import APP_CONST from '../../gobal/constants/app_contants.json';
import ELEM_CONST from '../../gobal/constants/element_constants.json';
import ROUTE_PATH from '../../gobal/constants/route_path_constants.json';

export const DesktopNav = props => {

    const { item, handleItemClick, children } = props;

    return (
        <React.Fragment>
            <Menu fixed='top' pointing secondary>
                <div className={ELEM_CONST.logoName}>
                    <HomeRoute />
                </div>
                <Menu.Menu position={ELEM_CONST.style.right}>
                    <MenuItems item={item} handleItemClick={handleItemClick} />
                </Menu.Menu>
            </Menu>
            {children}
        </React.Fragment>
    );
}

function HomeRoute() {
    return store.getState().accessToken.legnth === 0 ?
        <Link to={ROUTE_PATH.home}>
            <Header as='h1' content={APP_CONST.companyName} />
        </Link> :
        <Link to={combinedRoute(ROUTE_PATH.pre_admin_route, ROUTE_PATH.dashboard)}>
            <Header as='h1' content={APP_CONST.companyName} />
        </Link>
}
