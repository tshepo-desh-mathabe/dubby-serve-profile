import React, { Fragment } from 'react';
import { Menu } from 'semantic-ui-react';
import store from '../../app_store/store';
import APP_CONST from '../../gobal/constants/app_contants.json';

export const MenuItems = props => {
    const { item, handleItemClick } = props;

    return (store.getState().accessToken.length === 0 ?
        <GeneralItem
            item={item}
            handleItemClick={handleItemClick}
        /> :
        <AdminItem
            item={item}
            handleItemClick={handleItemClick}
        />
    );
}

export const GeneralItem = props => {
    const { item, handleItemClick } = props;

    return (
        <Fragment>
            <Menu.Item
                name={APP_CONST.home}
                active={item === APP_CONST.home}
                onClick={handleItemClick}
            />
            <Menu.Item
                name={APP_CONST.vacancyTraining}
                active={item === APP_CONST.vacancyTraining}
                onClick={handleItemClick}
            />
            <Menu.Item
                name={APP_CONST.enquiry}
                active={item === APP_CONST.enquiry}
                onClick={handleItemClick}
            />
            <Menu.Item
                name={APP_CONST.aboutUs}
                active={item === APP_CONST.aboutUs}
                onClick={handleItemClick}
            />
        </Fragment>
    );
}

export const AdminItem = props => {
    const { item, handleItemClick } = props;

    return (
        <Fragment>
            <Menu.Item
                name={APP_CONST.dashboard}
                active={item === APP_CONST.dashboard}
                onClick={handleItemClick}
            />
            <Menu.Item
                name={APP_CONST.journal}
                active={item === APP_CONST.journal}
                onClick={handleItemClick}
            />
            <Menu.Item
                name={APP_CONST.enquiry}
                active={item === APP_CONST.enquiry}
                onClick={handleItemClick}
            />
            <Menu.Item
                name={APP_CONST.vacancyTraining}
                active={item === APP_CONST.vacancyTraining}
                onClick={handleItemClick}
            />
            <Menu.Item
                name={APP_CONST.signOut}
                active={item === APP_CONST.signOut}
                onClick={handleItemClick}
            />
        </Fragment>
    );
}
