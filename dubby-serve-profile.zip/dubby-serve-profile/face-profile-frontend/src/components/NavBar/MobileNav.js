import React from 'react';
import { Sidebar, Menu, Icon, Header } from 'semantic-ui-react';
import { MenuItems } from './MenuItems';
import APP_CONST from '../../gobal/constants/app_contants.json';
import ELEM_CONST from '../../gobal/constants/element_constants.json';
import ROUTE_PATH from '../../gobal/constants/route_path_constants.json';
import { Link } from 'react-router-dom';

export const MobileNav = props => {

    const { children, onPusherClick, onToggle, visible, item, handleItemClick } = props;

    return (
        <Sidebar.Pushable>
            <Sidebar
                as={Menu}
                animation={ELEM_CONST.overlay}
                icon={ELEM_CONST.labeled}
                inverted
                direction='right'
                vertical
                visible={visible}
            >
                <MenuItems item={item} handleItemClick={handleItemClick} />
            </Sidebar>
            <Menu.Item onClick={onToggle}>
                <Icon name={ELEM_CONST.sidebar} />
            </Menu.Item>
            <Sidebar.Pusher
                dimmed={visible}
                onClick={onPusherClick}
            >
                <Menu fixed='top' inverted>
                    <Menu.Item>
                        <div className={ELEM_CONST.mobile_logo_name}>
                            <h1>
                                <Link to={ROUTE_PATH.home}>
                                    <Header as='h1' content={APP_CONST.companyName} />
                                </Link>
                            </h1>
                        </div>
                    </Menu.Item>
                    <Menu.Item onClick={onToggle}>
                        <Icon name={ELEM_CONST.sidebar} />
                    </Menu.Item>
                </Menu>
                <div id='menu-items' className='menu-items'>
                    {children}
                </div>
            </Sidebar.Pusher>
        </Sidebar.Pushable>
    );
}
