import React, { Component, Fragment } from 'react';
import { Container } from 'semantic-ui-react';
import history from '../../util/BrowserHistory';
import { DesktopNav } from './DeskopNav';
import { MobileNav } from './MobileNav';
import APP_CONST from '../../gobal/constants/app_contants.json';
import PATH from '../../gobal/constants/route_path_constants.json';
import ELEM_CONST from '../../gobal/constants/element_constants.json';
import STORE_CONST from '../../gobal/constants/app_state_constant.json';
import { isAdminPath } from '../../util/Validators';
import { combinedRoute } from '../../util/Utils';
import { connect } from 'react-redux';
import Login from '../Login/Login';

class NavigationBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      width: null,
      visible: false,

      activeItem: APP_CONST.home,
    };

    if (window.performance) {
      if (performance.navigation.type === performance.navigation.TYPE_RELOAD) {
        sessionStorage.clear();
        history.push(history.location.pathname);
      }
    }
  }

  componentDidMount() {
    switch (history.location.pathname) {
      case PATH.home:
        this.setState({ activeItem: APP_CONST.home });
        break;
      case PATH.aboutUs:
        this.setState({ activeItem: APP_CONST.aboutUs });
        break;
      case combinedRoute(PATH.pre_admin_route, PATH.journal):
        this.setState({ activeItem: APP_CONST.journal });
        break;
      case PATH.vacancyTraining:
      case combinedRoute(PATH.pre_admin_route, PATH.vacancyTraining):
        this.setState({ activeItem: APP_CONST.vacancyTraining });
        break;
      case PATH.enquiry:
      case combinedRoute(PATH.pre_admin_route, PATH.enquiry):
        this.setState({ activeItem: APP_CONST.enquiry });
        break;
      default:
        this.setState({ activeItem: APP_CONST.home });
        break;
    }

    window.addEventListener(APP_CONST.resize, this.handleResize.bind(this));
    this.handleResize();
  }

  handleResize() {
    this.setState({ width: window.innerWidth });
  }

  handlePusher = () => {
    const { visible } = this.state;

    if (visible) this.setState({ visible: false });
  };

  handleToggle = () => this.setState({ visible: !this.state.visible });

  handleItemClick = (e, { name }) => {
    const currentPath = history.location.pathname;
    this.setState({ activeItem: name });
    
    switch (name) {
      case APP_CONST.home:
        history.push(PATH.home);
        break;
      case APP_CONST.aboutUs:
        history.push(PATH.aboutUs);
        break;
      case APP_CONST.journal:
        history.push(combinedRoute(PATH.pre_admin_route, PATH.journal));
        break;
      case APP_CONST.vacancyTraining:
        isAdminPath(currentPath) ?
          history.push(combinedRoute(PATH.pre_admin_route, PATH.vacancyTraining)) : history.push(PATH.vacancyTraining);
        break;
      case APP_CONST.enquiry:
        isAdminPath(currentPath) ?
          history.push(combinedRoute(PATH.pre_admin_route, PATH.enquiry)) : history.push(PATH.enquiry);
        break;
      case APP_CONST.signOut:
        this.props.clearUserData();
        history.push(combinedRoute(PATH.pre_admin_route, PATH.login));
        break;
      default:
        history.push(PATH.default);
        break;
    }
  }
  render() {
    const { activeItem } = this.state;

    return (
      <Fragment>
        {
          history.location.pathname === `${PATH.pre_admin_route}${PATH.login}` ? <Login/> :
            <Fragment>
              {
                this.state.width <= APP_CONST.numberFormat.mobileScreenSize ?
                  <MobileNav
                    onToggle={this.handleToggle}
                    visible={this.state.visible}
                    onPusherClick={this.handlePusher}
                    item={activeItem}
                    handleItemClick={this.handleItemClick}
                  >
                    <NavBarChildren>{this.props.children}</NavBarChildren>
                  </MobileNav> :
                  <DesktopNav item={activeItem} handleItemClick={this.handleItemClick}>
                    <NavBarChildren>{this.props.children}</NavBarChildren>
                  </DesktopNav>
              }
            </Fragment>
        }
      </Fragment>
    )
  }
}

const NavBarChildren = props => (
  <Container style={{ marginTop: ELEM_CONST.size_5em }}>{props.children}</Container>
);

const mapDispacthToProps = (dispatch) => {
  return {
    clearUserData: () => dispatch({ type: STORE_CONST.clearLoggedInUser })
  }
}

export default connect(null, mapDispacthToProps)(NavigationBar);