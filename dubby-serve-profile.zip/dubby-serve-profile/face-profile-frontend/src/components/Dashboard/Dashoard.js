export const Dashboard = () => (
    <div>
        <h1 style={{color: 'wheat'}}>Dashboard</h1>
    </div>
)