package dubby.serve.profile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DubbyServeProfileBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
