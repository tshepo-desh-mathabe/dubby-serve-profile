package dubby.serve.profile.domain.dto.general;

import dubby.serve.profile.domain.dto.contact.EmailAddressDto;
import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
public class UserDto {

    private Long userId;

//    @NotBlank(message = EntityConstants.EMPTY_FIRST_NAME_SUBJECT)
    private String name;

//    @NotBlank(message = EntityConstants.EMPTY_LAST_NAME_SUBJECT)
    private String surname;

    @NotBlank(message = EntityConstants.NULL_PASSWORD)
    private String password;
    private EmailAddressDto emailAddressDetails;
    private Set<UserRoleDto> userRoleDetails;
}
