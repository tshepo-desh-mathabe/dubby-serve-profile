package dubby.serve.profile.repository;

import dubby.serve.profile.domain.general.Enquiry;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IEnquiryRepository extends PagingAndSortingRepository<Enquiry, Long> {
}
