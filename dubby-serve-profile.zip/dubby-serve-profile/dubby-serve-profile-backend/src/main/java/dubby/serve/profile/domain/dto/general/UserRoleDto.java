package dubby.serve.profile.domain.dto.general;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UserRoleDto {

    private Long userRoleId;
    private String role;
}
