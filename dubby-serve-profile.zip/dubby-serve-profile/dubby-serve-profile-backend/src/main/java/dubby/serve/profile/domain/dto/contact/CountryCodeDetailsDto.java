package dubby.serve.profile.domain.dto.contact;

import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@NoArgsConstructor
public class CountryCodeDetailsDto {

    private Long countryCodeId;
    private String countryIso;
    private String countryName1;
    private String CountryName2;
    private String countryIso3;
    private Short numCode;
    @NotBlank(message = EntityConstants.NULL_EMPTY_COUNTRY_CODE)
    private String code;
}
