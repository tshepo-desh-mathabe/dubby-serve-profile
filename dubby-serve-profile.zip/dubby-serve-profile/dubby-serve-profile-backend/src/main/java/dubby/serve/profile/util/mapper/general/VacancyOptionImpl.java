package dubby.serve.profile.util.mapper.general;

import dubby.serve.profile.domain.dto.general.VacancyOptionDto;
import dubby.serve.profile.domain.general.VacancyOption;
import dubby.serve.profile.util.contants.TrainingVacancyType;
import dubby.serve.profile.util.helper.IFieldPropertyMapper;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.mapper.helper.ListMapperHelper;
import org.springframework.stereotype.Component;

@Component
public class VacancyOptionImpl extends ListMapperHelper<VacancyOption, VacancyOptionDto> implements IModelMapper<VacancyOption, VacancyOptionDto> {

    @Override
    public VacancyOption toEntity(VacancyOptionDto dto) {
        return convertToEntity(dto);
    }

    @Override
    public VacancyOptionDto toDto(VacancyOption entity) {
        return convertToDto(entity);
    }

    private VacancyOptionDto convertToDto(VacancyOption vacancyOption) {
        if (vacancyOption != null) {
            IFieldPropertyMapper<VacancyOptionDto> mapper = destination -> {
                destination.setVacancyOptionId(vacancyOption.getId());
                destination.setVacancyOption(String.valueOf(vacancyOption.getVacancyOption()));

                return destination;
            };

            return mapper.mapTo(new VacancyOptionDto());
        } else {
            return null;
        }
    }

    private VacancyOption convertToEntity(VacancyOptionDto vacancyOptionDto) {
        if (vacancyOptionDto != null) {
            IFieldPropertyMapper<VacancyOption> mapper = destination -> {
                destination.setId(vacancyOptionDto.getVacancyOptionId());
                destination.setVacancyOption(TrainingVacancyType.valueOf(vacancyOptionDto.getVacancyOption()));

                return destination;
            };

            return mapper.mapTo(new VacancyOption());
        } else {
            return null;
        }
    }
}
