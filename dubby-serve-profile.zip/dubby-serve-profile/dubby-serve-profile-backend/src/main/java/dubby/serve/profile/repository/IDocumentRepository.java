package dubby.serve.profile.repository;

import dubby.serve.profile.domain.general.Document;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IDocumentRepository extends PagingAndSortingRepository<Document, Long> {
}
