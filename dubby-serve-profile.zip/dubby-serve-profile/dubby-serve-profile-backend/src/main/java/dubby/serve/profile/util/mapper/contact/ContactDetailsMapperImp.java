package dubby.serve.profile.util.mapper.contact;

import dubby.serve.profile.domain.contact.ContactDetails;
import dubby.serve.profile.domain.dto.contact.ContactDetailsDto;
import dubby.serve.profile.util.helper.IFieldPropertyMapper;
import dubby.serve.profile.util.helper.IModelMapper;
import org.springframework.stereotype.Component;

@Component
public class ContactDetailsMapperImp implements IModelMapper<ContactDetails, ContactDetailsDto> {

    @Override
    public ContactDetails toEntity(ContactDetailsDto dto) {
        return convertToEntity(dto);
    }

    @Override
    public ContactDetailsDto toDto(ContactDetails entity) {
        return convertToDto(entity);
    }

    private ContactDetailsDto convertToDto(ContactDetails contactDetails) {
        if (contactDetails != null) {
            IFieldPropertyMapper<ContactDetailsDto> mapper = destination -> {
                destination.setContactDetailsId(contactDetails.getContactId());
                destination.setPhoneNumberDetails(new PhoneNumberMapperImp().toDto(contactDetails.getPhoneNumber()));
                destination.setEmailAddressDetails(new EmailAddressMapperImpl().toDto(contactDetails.getEmailAddress()));

                return destination;
            };

            return mapper.mapTo(new ContactDetailsDto());
        } else {
            return null;
        }
    }
    
    private ContactDetails convertToEntity(ContactDetailsDto contactDetailsDto) {
        if (contactDetailsDto != null) {
            IFieldPropertyMapper<ContactDetails> mapper = destination -> {
                destination.setContactId(contactDetailsDto.getContactDetailsId());
                destination.setPhoneNumber(new PhoneNumberMapperImp().toEntity(contactDetailsDto.getPhoneNumberDetails()));
                destination.setEmailAddress(new EmailAddressMapperImpl().toEntity(contactDetailsDto.getEmailAddressDetails()));

                return destination;
            };

            return mapper.mapTo(new ContactDetails());
        } else {
            return null;
        }
    }
}
