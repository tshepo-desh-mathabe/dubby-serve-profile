package dubby.serve.profile.util.helper;

import dubby.serve.profile.util.response.ApiResponse;

@FunctionalInterface
public interface ICheck<T> {

    ApiResponse<?> checkData(T data);
}