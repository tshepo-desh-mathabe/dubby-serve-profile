package dubby.serve.profile.util.mapper.general;

import dubby.serve.profile.domain.dto.general.EnquiryDto;
import dubby.serve.profile.domain.general.Enquiry;
import dubby.serve.profile.util.helper.IFieldPropertyMapper;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.mapper.contact.ContactDetailsMapperImp;
import dubby.serve.profile.util.mapper.helper.ListMapperHelper;
import org.springframework.stereotype.Component;

@Component
public class EnquiryMapperImpl extends ListMapperHelper<Enquiry, EnquiryDto> implements IModelMapper<Enquiry, EnquiryDto> {
    
    @Override
    public Enquiry toEntity(EnquiryDto dto) {
        return convertToEntity(dto);
    }

    @Override
    public EnquiryDto toDto(Enquiry entity) {
        return convertToDto(entity);
    }

    private EnquiryDto convertToDto(Enquiry enquiry) {
        if (enquiry != null) {
            IFieldPropertyMapper<EnquiryDto> mapper = destination -> {
                destination.setEnquiryId(enquiry.getId());
                destination.setName(enquiry.getFirstName());
                destination.setSurname(enquiry.getLastName());
                destination.setMessageSubject(enquiry.getSubject());
                destination.setMessageBody(enquiry.getMessage());
                destination.setCreateAt(enquiry.getCreatedAt());
                destination.setIsDelete(enquiry.getSoftDelete());
                destination.setIsRead(enquiry.getIsRead());
                destination.setContactDetailsDetails(new ContactDetailsMapperImp().toDto(enquiry.getContactDetails()));

                return destination;
            };

            return mapper.mapTo(new EnquiryDto());
        } else {
            return null;
        }
    }

    private Enquiry convertToEntity(EnquiryDto enquiryDto) {
        if (enquiryDto != null) {
            IFieldPropertyMapper<Enquiry> mapper = destination -> {
                destination.setId(enquiryDto.getEnquiryId());
                destination.setFirstName(enquiryDto.getName());
                destination.setLastName(enquiryDto.getSurname());
                destination.setSubject(enquiryDto.getMessageSubject());
                destination.setMessage(enquiryDto.getMessageBody());
                destination.setCreatedAt(enquiryDto.getCreateAt());
                destination.setSoftDelete(enquiryDto.getIsDelete());
                destination.setIsRead(enquiryDto.getIsRead());
                destination.setContactDetails(new ContactDetailsMapperImp().toEntity(enquiryDto.getContactDetailsDetails()));

                return destination;
            };

            return mapper.mapTo(new Enquiry());
        } else {
            return null;
        }
    }
}
