package dubby.serve.profile.payload;

import dubby.serve.profile.util.contants.FlagHelper;

public record ReadDeletePayload(Long id, FlagHelper flagHelper, Boolean flag) {
}
