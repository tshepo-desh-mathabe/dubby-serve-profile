package dubby.serve.profile.util.validator;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import org.springframework.stereotype.Component;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

@Component
public class ValidatorImpl implements IValidator {

    public boolean validatePhoneNumber(String countryCode, String number) {
        final PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();

        if (countryCode != null && number != null) {
            String region = phoneUtil.getRegionCodeForCountryCode(Integer.parseInt(countryCode));
            Phonenumber.PhoneNumber phoneNumber = null;

            try {
                phoneNumber = phoneUtil.parse(number, region.toUpperCase());
            } catch (NumberParseException ex) {
                return false;
            }

            return phoneUtil.isValidNumber(phoneNumber);
        }
        return false;
    }

    public boolean isValidEmailAddress(String email) {
        boolean result = true;
        try {
            InternetAddress address = new InternetAddress(email);
            address.validate();
        } catch (AddressException ex) {
            result = false;
        }
        return result;
    }
}
