package dubby.serve.profile.util.mapper.general;

import dubby.serve.profile.domain.dto.general.VacancyDto;
import dubby.serve.profile.domain.general.Vacancy;
import dubby.serve.profile.util.helper.IFieldPropertyMapper;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.mapper.contact.ContactDetailsMapperImp;
import dubby.serve.profile.util.mapper.helper.ListMapperHelper;
import org.springframework.stereotype.Component;

@Component
public class VacancyMapperImpl extends ListMapperHelper<Vacancy, VacancyDto> implements IModelMapper<Vacancy, VacancyDto> {
    
    @Override
    public Vacancy toEntity(VacancyDto dto) {
        return convertToEntity(dto);
    }

    @Override
    public VacancyDto toDto(Vacancy entity) {
        return convertToDto(entity);
    }

    private VacancyDto convertToDto(Vacancy vacancy) {
        if (vacancy != null) {
            IFieldPropertyMapper<VacancyDto> mapper = destination -> {
                destination.setVacancyId(vacancy.getId());
                destination.setName(vacancy.getFirstName());
                destination.setSurname(vacancy.getLastName());
                destination.setMessageBody(vacancy.getMessage());
                destination.setCreateAt(vacancy.getCreatedAt());
                destination.setIsRead(vacancy.getIsRead());
                destination.setIsDelete(vacancy.getSoftDelete());
                destination.setVacancyOptionDetails(new VacancyOptionImpl().toDto(vacancy.getVacancyOption()));
                destination.setContactDetailsDetails(new ContactDetailsMapperImp().toDto(vacancy.getContactDetails()));
                destination.setDocuments(new DocumentMapperImpl().toDto(vacancy.getFiles()));

                return destination;
            };

            return mapper.mapTo(new VacancyDto());
        } else {
            return null;
        }
    }

    private Vacancy convertToEntity(VacancyDto vacancyDto) {
        if (vacancyDto != null) {
            IFieldPropertyMapper<Vacancy> mapper = destination -> {
                destination.setId(vacancyDto.getVacancyId());
                destination.setFirstName(vacancyDto.getName());
                destination.setLastName(vacancyDto.getSurname());
                destination.setMessage(vacancyDto.getMessageBody());
                destination.setCreatedAt(vacancyDto.getCreateAt());
                destination.setIsRead(vacancyDto.getIsRead());
                destination.setSoftDelete(vacancyDto.getIsDelete());
                destination.setVacancyOption(new VacancyOptionImpl().toEntity(vacancyDto.getVacancyOptionDetails()));
                destination.setContactDetails(new ContactDetailsMapperImp().toEntity(vacancyDto.getContactDetailsDetails()));
                destination.setFiles(new DocumentMapperImpl().toEntity(vacancyDto.getDocuments()));

                return destination;
            };

            return mapper.mapTo(new Vacancy());
        } else {
            return null;
        }
    }
}
