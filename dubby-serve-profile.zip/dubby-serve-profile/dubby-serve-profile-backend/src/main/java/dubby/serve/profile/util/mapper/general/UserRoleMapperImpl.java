package dubby.serve.profile.util.mapper.general;

import dubby.serve.profile.domain.dto.general.UserRoleDto;
import dubby.serve.profile.domain.general.UserRole;
import dubby.serve.profile.util.contants.RoleType;
import dubby.serve.profile.util.helper.IFieldPropertyMapper;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.mapper.helper.ListMapperHelper;
import org.springframework.stereotype.Component;

@Component
public class UserRoleMapperImpl extends ListMapperHelper<UserRole, UserRoleDto> implements IModelMapper<UserRole, UserRoleDto> {

    @Override
    public UserRole toEntity(UserRoleDto dto) {
        return convertToEntity(dto);
    }

    @Override
    public UserRoleDto toDto(UserRole entity) {
        return convertToDto(entity);
    }

    private UserRoleDto convertToDto(UserRole userRole) {
        if (userRole != null) {
            IFieldPropertyMapper<UserRoleDto> mapper = destination -> {
                destination.setUserRoleId(userRole.getId());
                destination.setRole(String.valueOf(userRole.getRoleType()));

                return destination;
            };

            return mapper.mapTo(new UserRoleDto());
        } else {
            return null;
        }
    }

    private UserRole convertToEntity(UserRoleDto roleDto) {
        if (roleDto != null) {
            IFieldPropertyMapper<UserRole> mapper = destination -> {
                destination.setId(roleDto.getUserRoleId());
                destination.setRoleType(RoleType.valueOf(roleDto.getRole()));

                return destination;
            };

            return mapper.mapTo(new UserRole());
        } else {
            return null;
        }
    }
}
