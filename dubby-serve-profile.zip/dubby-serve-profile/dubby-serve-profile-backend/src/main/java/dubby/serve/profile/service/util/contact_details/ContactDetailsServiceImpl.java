package dubby.serve.profile.service.util.contact_details;

import dubby.serve.profile.domain.contact.ContactDetails;
import dubby.serve.profile.domain.contact.EmailAddress;
import dubby.serve.profile.domain.contact.PhoneNumber;
import dubby.serve.profile.repository.IContactDetailsRepository;
import dubby.serve.profile.util.helper.ICheck;
import dubby.serve.profile.util.response.ApiResponse;
import dubby.serve.profile.util.response.ApiResponseHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ContactDetailsServiceImpl implements ICheck<ContactDetails> {

    @Autowired
    private ICheck<PhoneNumber> phoneNumberService;
    @Autowired
    private ICheck<EmailAddress> emailAddressService;
    @Autowired
    private IContactDetailsRepository contactDetailsRepository;

    public ApiResponse<?> checkData(ContactDetails contactDetails) {
        ApiResponse savePhoneNumber = phoneNumberService.checkData(contactDetails.getPhoneNumber());
        ApiResponse saveEmailAddress = emailAddressService.checkData(contactDetails.getEmailAddress());

        if (savePhoneNumber.getSuccess().equals(false)) {
            return savePhoneNumber;
        } else {
            if (savePhoneNumber.getMessage() instanceof PhoneNumber data) {
                contactDetails.setPhoneNumber(data);
            }
        }

        if (saveEmailAddress.getSuccess().equals(false)) {
            return saveEmailAddress;
        } else {
            if (saveEmailAddress.getMessage() instanceof EmailAddress data) {
                contactDetails.setEmailAddress(data);
            }
        }

        return ApiResponseHelper.okResponse(contactDetails);
    }
}
