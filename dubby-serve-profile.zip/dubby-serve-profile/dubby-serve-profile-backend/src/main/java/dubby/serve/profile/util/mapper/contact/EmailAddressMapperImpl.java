package dubby.serve.profile.util.mapper.contact;

import dubby.serve.profile.domain.contact.EmailAddress;
import dubby.serve.profile.domain.dto.contact.EmailAddressDto;
import dubby.serve.profile.util.helper.IFieldPropertyMapper;
import dubby.serve.profile.util.helper.IModelMapper;
import org.springframework.stereotype.Component;

@Component
public class EmailAddressMapperImpl implements IModelMapper<EmailAddress, EmailAddressDto> {

    @Override
    public EmailAddress toEntity(EmailAddressDto dto) {
        return convertToEntity(dto);
    }

    @Override
    public EmailAddressDto toDto(EmailAddress entity) {
        return convertToDto(entity);
    }

    private EmailAddressDto convertToDto(EmailAddress emailAddress) {
        if (emailAddress != null) {
            IFieldPropertyMapper<EmailAddressDto> mapper = destination -> {
                destination.setAddressId(emailAddress.getEmailId());
                destination.setEmailAddress(emailAddress.getAddress());

                return destination;
            };

            return mapper.mapTo(new EmailAddressDto());
        } else {
            return null;
        }
    }

    private EmailAddress convertToEntity(EmailAddressDto emailAddressDto) {
        if (emailAddressDto != null) {
            IFieldPropertyMapper<EmailAddress> mapper = destination -> {
                destination.setEmailId(emailAddressDto.getAddressId());
                destination.setAddress(emailAddressDto.getEmailAddress());

                return destination;
            };

            return mapper.mapTo(new EmailAddress());
        } else {
            return null;
        }
    }
}
