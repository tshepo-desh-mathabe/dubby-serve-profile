package dubby.serve.profile.util.helper;

@FunctionalInterface
public interface IFinder<T> {

    Object findWithString(String searchValue);
}
