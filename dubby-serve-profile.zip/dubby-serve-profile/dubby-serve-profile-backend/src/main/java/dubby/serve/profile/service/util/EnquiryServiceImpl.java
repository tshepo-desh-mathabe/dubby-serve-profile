package dubby.serve.profile.service.util;

import dubby.serve.profile.domain.dto.general.EnquiryDto;
import dubby.serve.profile.domain.general.Enquiry;
import dubby.serve.profile.payload.ReadDeletePayload;
import dubby.serve.profile.repository.IEnquiryRepository;
import dubby.serve.profile.util.contants.AppConstant;
import dubby.serve.profile.util.contants.FlagHelper;
import dubby.serve.profile.util.helper.ICrudServiceResponse;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.property_fetcher.IPropertyFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class EnquiryServiceImpl implements ICrudServiceResponse<EnquiryDto> {

    private final FlagHelper serviceFlag = FlagHelper.IS_VACANCY;
    @Autowired
    private IEnquiryRepository repository;
    @Autowired
    private IModelMapper<Enquiry, EnquiryDto> mapper;
    @Autowired
    private IPropertyFetcher<AppConstant> propertyFetcher;
    @Autowired
    private CrudHelper<Enquiry, EnquiryDto> crudHelper;

    @Override
    public ResponseEntity<?> save(EnquiryDto payload) {
        Enquiry enquiry = mapper.toEntity(payload);
        return crudHelper.saveData(enquiry, AppConstant.ENQUIRY_MADE_MESSAGE, repository);
    }

    @Override
    public ResponseEntity<?> getById(Long id) {
        ResponseEntity<?> response = crudHelper.retrieveOneById(serviceFlag, id, repository);

        if (!response.getStatusCode().equals(HttpStatus.BAD_REQUEST)) {
            if (response.getBody() instanceof Enquiry enquiry) {
                return ResponseEntity.ok(mapper.toDto(enquiry));
            }
        }
        return response;
    }

    @Override
    public ResponseEntity<?> retrieveAll(Pageable pageable) {
        return crudHelper.getAllDataPagination(serviceFlag, pageable, repository);
    }

    @Override
    public ResponseEntity<?> deleteOneById(Long id) {
        return crudHelper.deleteObjectById(serviceFlag, id, repository);
    }

    @Override
    public ResponseEntity<?> deleteAll(Long[] ids) {
        return crudHelper.deleteAllByIds(serviceFlag, ids, repository);
    }

    @Override
    public ResponseEntity<?> updateReadOrDelete(ReadDeletePayload readDeletePayload) {
        return crudHelper.editAndSaveReadSoftDelete(serviceFlag, readDeletePayload, repository);
    }
}
