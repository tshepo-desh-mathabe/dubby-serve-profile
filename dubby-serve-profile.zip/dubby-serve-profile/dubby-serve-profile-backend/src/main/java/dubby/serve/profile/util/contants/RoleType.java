package dubby.serve.profile.util.contants;

public enum RoleType {
    ROLE_USER, ROLE_ADMIN
}
