package dubby.serve.profile.service.util.contact_details;

import dubby.serve.profile.domain.contact.CountryCodeDetails;
import dubby.serve.profile.domain.contact.PhoneNumber;
import dubby.serve.profile.domain.dto.contact.CountryCodeDetailsDto;
import dubby.serve.profile.domain.dto.contact.PhoneNumberDto;
import dubby.serve.profile.repository.IPhoneNumberRepository;
import dubby.serve.profile.util.contants.AppConstant;
import dubby.serve.profile.util.helper.ICheck;
import dubby.serve.profile.util.helper.ICrudServiceApi;
import dubby.serve.profile.util.helper.IFinder;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.property_fetcher.IPropertyFetcher;
import dubby.serve.profile.util.response.ApiResponse;
import dubby.serve.profile.util.response.ApiResponseHelper;
import dubby.serve.profile.util.validator.IValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * This bean does not PERSIST data
 */
@Component
public class PhoneNumberServiceImpl implements ICrudServiceApi<PhoneNumberDto>, ICheck<PhoneNumber> {

    private static final Logger logger = LoggerFactory.getLogger(PhoneNumberServiceImpl.class);

    @Autowired
    private IPhoneNumberRepository phoneNumberRepository;
    @Autowired
    private IPropertyFetcher<AppConstant> propertyFetcher;
    @Autowired
    private IModelMapper<PhoneNumber, PhoneNumberDto> phoneNumberMapper;
    @Autowired
    private IModelMapper<CountryCodeDetails, CountryCodeDetailsDto> countryCodeDetailsMapper;
    @Autowired
    private IFinder<CountryCodeDetailsDto> countryCodeFinder;
    @Autowired
    private IValidator validator;

    public ApiResponse<?> checkData(PhoneNumber payload) {
        CountryCodeDetailsDto countryCodeDetails = (CountryCodeDetailsDto) countryCodeFinder.findWithString(payload.getCountryCodeDetails().getCode());

        if (validator.validatePhoneNumber(countryCodeDetails.getCode(), payload.getNumber())) {
            if (phoneNumberRepository.existsByNumber(payload.getNumber())) {
                return ApiResponseHelper.badResponse(propertyFetcher.getProperty(AppConstant.PHONE_NUMBER_EXISTS));
            }
        } else {
            return ApiResponseHelper.badResponse(propertyFetcher.getProperty(AppConstant.BAD_PHONE_NUMBER_FORMAT));
        }

        PhoneNumber phoneNumber = new PhoneNumber();
        phoneNumber.setCountryCodeDetails(countryCodeDetailsMapper.toEntity(countryCodeDetails));
        phoneNumber.setNumber(payload.getNumber());

        return ApiResponseHelper.okResponse(phoneNumber);
    }

    @Override
    public ApiResponse<?> findWithString(String searchValue) {
        Optional<PhoneNumber> phoneNumber = phoneNumberRepository.findByNumber(searchValue);

        try {
            if (phoneNumber.isEmpty()) {
                return ApiResponseHelper.okResponse(propertyFetcher.getProperty(AppConstant.NO_DATA_MESSAGE));
            } else {
                return ApiResponseHelper.okResponse(phoneNumberMapper.toDto(phoneNumber.get()));
            }
        } catch (Exception ex) {
            return ApiResponseHelper.badResponse(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
        }
    }

    @Override
    public ApiResponse<?> retrieveAll() {
        Set<PhoneNumber> phoneNumbers = new HashSet<>();
        phoneNumberRepository.findAll().forEach(phoneNumbers::add);

        try {
            if (!phoneNumbers.isEmpty()) {
                Set<PhoneNumberDto> data = phoneNumberMapper.toDto(phoneNumbers);
                return ApiResponseHelper.okResponse(data);
            }
            return ApiResponseHelper.okResponse(propertyFetcher.getProperty(AppConstant.NO_DATA_MESSAGE));
        } catch (Exception ex) {
            logger.error("Get Via Pagination -->", ex);
            return ApiResponseHelper.badResponse(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
        }
    }
}
