package dubby.serve.profile.service.util;

import dubby.serve.profile.domain.contact.ContactDetails;
import dubby.serve.profile.domain.general.Enquiry;
import dubby.serve.profile.domain.general.Vacancy;
import dubby.serve.profile.payload.ReadDeletePayload;
import dubby.serve.profile.repository.IEnquiryRepository;
import dubby.serve.profile.repository.IVacancyRepository;
import dubby.serve.profile.util.contants.AppConstant;
import dubby.serve.profile.util.contants.FlagHelper;
import dubby.serve.profile.util.helper.ICheck;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.mail.IMailBody;
import dubby.serve.profile.util.mail.PrepareMail;
import dubby.serve.profile.util.mapper.general.EnquiryMapperImpl;
import dubby.serve.profile.util.mapper.general.VacancyMapperImpl;
import dubby.serve.profile.util.property_fetcher.IPropertyFetcher;
import dubby.serve.profile.util.response.ApiResponse;
import dubby.serve.profile.util.response.ResponseApiWrapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Optional;
import java.util.Set;

/**
 * Helps to perform CRUD operations, provided that there is only 2 services in play
 *
 * @param <E> entity
 */
@Component
public class CrudHelper<E, D> {

    private static final Logger logger = LoggerFactory.getLogger(CrudHelper.class);

    @Autowired
    private IPropertyFetcher propertyFetcher;
    @Autowired
    private ICheck<ContactDetails> contactDetailsChecker;
    @Autowired
    private PrepareMail prepareMail;

    public ResponseEntity<?> saveData(E data, AppConstant message, Object repository) {
        try {
            if (data instanceof Vacancy vacancy) {
                ApiResponse checkerDetails = contactCheck(vacancy.getContactDetails());
                if (checkerDetails.getSuccess().equals(false)) {
                    return ResponseApiWrapper.badRequest(checkerDetails.getMessage());
                } else {
                    vacancy.setContactDetails((ContactDetails) checkerDetails.getMessage());
                }

                ((IVacancyRepository) repository).save(vacancy);
                prepareMail.send(
                        vacancy.getContactDetails().getEmailAddress().getAddress(),
                        String.format("%s %s", vacancy.getFirstName(), vacancy.getLastName())
                        , null
                );
            } else if (data instanceof Enquiry enquiry) {
                ApiResponse checkerDetails = contactCheck(enquiry.getContactDetails());
                if (checkerDetails.getSuccess().equals(false)) {
                    return  ResponseApiWrapper.badRequest(checkerDetails.getMessage());
                } else {
                    enquiry.setContactDetails((ContactDetails) checkerDetails.getMessage());
                }

                ((IEnquiryRepository) repository).save(enquiry);
                prepareMail.send(
                        enquiry.getContactDetails().getEmailAddress().getAddress(),
                        enquiry.getFirstName() + " " + enquiry.getLastName(),
                        String.format("Re: %s", enquiry.getSubject())
                );
            }
        } catch (Exception ex) {
            return ResponseApiWrapper.badRequest(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
        }
        return ResponseApiWrapper.okRequest(propertyFetcher.getProperty(message));
    }

    public ResponseEntity<?> retrieveOneById(FlagHelper flagHelper, Long id, Object repository) {
        Optional<E> vacancy = null;
        try {
            if (flagHelper.equals(FlagHelper.IS_VACANCY)) {
                vacancy = (Optional<E>) ((IVacancyRepository) repository).findById(id);
            } else if (flagHelper.equals(FlagHelper.IS_ENQUIRY)) {
                vacancy = (Optional<E>) ((IEnquiryRepository) repository).findById(id);
            }

            if (vacancy.isEmpty()) {
                return ResponseApiWrapper.okRequest(propertyFetcher.getProperty(AppConstant.NO_DATA_MESSAGE));
            } else {
                return ResponseApiWrapper.okRequest(vacancy.get());
            }
        } catch (Exception ex) {
            logger.error("Get By ID -->", ex);
            return ResponseApiWrapper.badRequest(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
        }
    }

    // todo - look carefully, trust you will see
    public ResponseEntity<?> getAllDataPagination(FlagHelper flagHelper, Pageable pageable, Object repository) {
        try {
            IModelMapper mapper = null;
            Page<E> vacancies = null;

            if (flagHelper.equals(FlagHelper.IS_VACANCY)) {
                vacancies = (Page<E>) ((IVacancyRepository) repository).findAll(pageable);
                mapper = new VacancyMapperImpl();
            } else if (flagHelper.equals(FlagHelper.IS_ENQUIRY)) {
                vacancies = (Page<E>) ((IEnquiryRepository) repository).findAll(pageable);
                mapper = new EnquiryMapperImpl();
            }

            if (!vacancies.isEmpty()) {
                Set<D> data = (Set<D>) mapper.toDto(vacancies.getContent());
                return ResponseApiWrapper.okRequest(data);
            }
            return ResponseApiWrapper.okRequest(propertyFetcher.getProperty(AppConstant.NO_DATA_MESSAGE));
        } catch (Exception ex) {
            logger.error("Get Via Pagination -->", ex);
            return ResponseApiWrapper.badRequest(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
        }
    }

    public ResponseEntity<?> deleteObjectById(FlagHelper flagHelper, Long id, Object repository) {
        try {
            if (flagHelper.equals(FlagHelper.IS_VACANCY)) {
                ((IVacancyRepository) repository).deleteById(id);
            } else if (flagHelper.equals(FlagHelper.IS_ENQUIRY)) {
                ((IEnquiryRepository) repository).deleteById(id);
            }
            return ResponseApiWrapper.okRequest(propertyFetcher.getProperty(AppConstant.SUCCESS_DELETE_MESSAGE));
        } catch (Exception ex) {
            logger.error("Delete By ID -->", ex);
            return ResponseApiWrapper.badRequest(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
        }
    }

    public ResponseEntity<?> deleteAllByIds(FlagHelper flagHelper, Long[] ids, Object repository) {
        try {
            Iterable<Long> data = Arrays.asList(ids);
            if (flagHelper.equals(FlagHelper.IS_VACANCY)) {
                ((IVacancyRepository) repository).deleteAllById(data);
            } else if (flagHelper.equals(FlagHelper.IS_ENQUIRY)) {
                ((IEnquiryRepository) repository).deleteAllById(data);
            }
            return ResponseApiWrapper.okRequest(propertyFetcher.getProperty(AppConstant.SUCCESS_DELETE_MESSAGE));
        } catch (Exception ex) {
            logger.error("Delete All By ID -->", ex);
            return ResponseApiWrapper.badRequest(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
        }
    }

    public ResponseEntity<?> editAndSaveReadSoftDelete(FlagHelper flagHelper, ReadDeletePayload payload, Object repository) {
        ResponseEntity responseEntity = retrieveOneById(flagHelper, payload.id(), repository);

        if (payload.flagHelper() != null) { // fail faster
            if (responseEntity.getStatusCode().equals(HttpStatus.BAD_REQUEST)) {
                return responseEntity;
            } else {
                if (responseEntity.getBody() instanceof Enquiry enquiry) {
                    return editReadSoftDelete(flagHelper, (E) enquiry, repository);
                } else if (responseEntity.getBody() instanceof Vacancy vacancy) {
                    return editReadSoftDelete(flagHelper, (E) vacancy, repository);
                }
            }
            return ResponseApiWrapper.badRequest(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
        }
        return ResponseApiWrapper.badRequest(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
    }

    private ApiResponse<?> contactCheck(ContactDetails payload) {
        ApiResponse dataChecker = contactDetailsChecker.checkData(payload);
        return dataChecker;
    }

    private ResponseEntity<?> editReadSoftDelete(FlagHelper flagHelper, E data, Object repository) {
        switch (flagHelper) {
            case SOFT_DELETE:
                if (data instanceof Vacancy vacancy) {
                    vacancy.setSoftDelete(true);
                } else if (data instanceof Enquiry enquiry) {
                    enquiry.setSoftDelete(true);
                }
                return saveData(data, AppConstant.SUCCESS_DELETE_MESSAGE, repository);
            case IS_READ:
                if (data instanceof Vacancy vacancy) {
                    vacancy.setIsRead(true);
                } else if (data instanceof Enquiry enquiry) {
                    enquiry.setIsRead(true);
                }
                return saveData(data, AppConstant.SUCCESS_DELETE_MESSAGE, repository);
            default:
                return ResponseApiWrapper.badRequest(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
        }
    }
}
