package dubby.serve.profile.util.helper;

import dubby.serve.profile.util.contants.TrainingVacancyType;
import dubby.serve.profile.util.response.ApiResponse;
import org.springframework.data.domain.Pageable;

import java.util.Set;

/**
 * Helps with CRUD operations for API
 * @param <D> dto as the payload
 */
public interface ICrudServiceApi<D> {

    default ApiResponse<?> save(D payload) throws Exception {
        return null;
    }

    default ApiResponse<?> save(Set<D> payload) throws Exception {
        return null;
    }

    default ApiResponse<?> retrieveAll(Pageable pageable) throws Exception {
        return null;
    }

    default ApiResponse<?> retrieveAll() throws Exception {
        return null;
    }

    default ApiResponse<?> findWithString(String searchValue) {
        return null;
    }

    default ApiResponse<?> findWithId(Long id) {
        return null;
    }
}

