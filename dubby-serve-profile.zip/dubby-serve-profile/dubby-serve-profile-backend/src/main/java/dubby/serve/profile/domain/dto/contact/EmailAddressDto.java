package dubby.serve.profile.domain.dto.contact;

import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

@Getter
@Setter
@NoArgsConstructor
public class EmailAddressDto {

    private Long addressId;

    @Email(message = EntityConstants.EMAIL_FORMAT_INCORRECT)
    @NotBlank(message = EntityConstants.NULL_EMPTY_EMAIL_ADDRESS)
    String emailAddress;
}