package dubby.serve.profile.util.validator;

public interface IValidator {

    boolean validatePhoneNumber(String countryCode, String number);

    boolean isValidEmailAddress(String email);
}
