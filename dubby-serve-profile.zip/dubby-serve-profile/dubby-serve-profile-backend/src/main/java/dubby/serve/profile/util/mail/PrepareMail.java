package dubby.serve.profile.util.mail;

import dubby.serve.profile.util.contants.AppConstant;
import dubby.serve.profile.util.property_fetcher.IPropertyFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;

@Component
public class PrepareMail {

    @Autowired
    private IMailBody mailBody;
    @Autowired
    private EmailUtil emailUtil;
    @Autowired
    private IPropertyFetcher propertyFetcher;

    public void send(String emailAddress, String name, String messageSubject) {
        if (messageSubject == null) {
            messageSubject = propertyFetcher.getProperty(AppConstant.EMAIL_SUBJECT_VACANCY_MESSAGE);
        }

        String htmlBody = mailBody.htmlMessageBody(name);
        try {
            emailUtil.sendMail(emailAddress, messageSubject, htmlBody);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}
