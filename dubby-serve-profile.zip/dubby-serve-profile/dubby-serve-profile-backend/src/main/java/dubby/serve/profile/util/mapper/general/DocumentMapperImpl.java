package dubby.serve.profile.util.mapper.general;

import dubby.serve.profile.domain.dto.general.DocumentDto;
import dubby.serve.profile.domain.general.Document;
import dubby.serve.profile.util.helper.IFieldPropertyMapper;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.mapper.helper.ListMapperHelper;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Component
public class DocumentMapperImpl extends ListMapperHelper<Document, DocumentDto> implements IModelMapper<Document, DocumentDto> {
    
    @Override
    public Document toEntity(DocumentDto dto) {
        return convertToEntity(dto);
    }

    @Override
    public DocumentDto toDto(Document entity) {
        return convertToDto(entity);
    }

    @Override
    public Set<Document> toEntity(Set<DocumentDto> dtos) {
        return convertToEntity(dtos);
    }

    @Override
    public Set<DocumentDto> toDto(Set<Document> entities) {
        return convertToDto(entities);
    }

    private DocumentDto convertToDto(Document document) {
        if (document != null) {
            IFieldPropertyMapper<DocumentDto> mapper = destination -> {
                destination.setDocumentId(document.getId());
                destination.setFileData(document.getFile());

                return destination;
            };

            return mapper.mapTo(new DocumentDto());
        } else {
            return null;
        }
    }

    private Document convertToEntity(DocumentDto documentDto) {
        if (documentDto != null) {
            IFieldPropertyMapper<Document> mapper = destination -> {
                destination.setId(documentDto.getDocumentId());
                destination.setFile(documentDto.getFileData());

                return destination;
            };

            return mapper.mapTo(new Document());
        } else {
            return null;
        }
    }

    private Set<DocumentDto> convertToDto(Set<Document> document) {
        if (!document.isEmpty()) {
            Document[] data = document.toArray(new Document[document.size()]);
            Set<DocumentDto> documents = new HashSet<>();

            for (int i = 0; i < data.length; i++) {
                documents.add(convertToDto(data[i]));
            }

            return documents;
        } else {
            return null;
        }
    }

    private Set<Document> convertToEntity(Set<DocumentDto> documentDto) {
        if (!documentDto.isEmpty()) {
            DocumentDto[] data = documentDto.toArray(new DocumentDto[documentDto.size()]);
            Set<Document> documents = new HashSet<>();

            for (int i = 0; i < data.length; i++) {
                documents.add(convertToEntity(data[i]));
            }

            return documents;
        } else {
            return null;
        }
    }
}
