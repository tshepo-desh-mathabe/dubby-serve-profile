package dubby.serve.profile.domain.general;

import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Data
@Entity
@NoArgsConstructor
@Table(name = EntityConstants.DOCUMENT)
public class Document {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = EntityConstants.DOCUMENT_ID)
    private Long id;

    @Lob
    @NotNull
    @Column(name = EntityConstants.FILE, length = 1000)
    private Byte[] file;
}
