package dubby.serve.profile.domain.helper;

import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class DateAudit {

    @NotNull
    @CreatedDate
    @Column(name = EntityConstants.CREATED_AT)
    private LocalDateTime createdAt;

    @NotNull
    @Column(columnDefinition = EntityConstants.SMALL_INT_DEFAULT_0)
    private Boolean isRead;

    @NotNull
    @Column(columnDefinition = EntityConstants.SMALL_INT_DEFAULT_0)
    private Boolean softDelete;

    @PrePersist
    protected void beforePersistingCreatedAt() {
        if (createdAt == null ) createdAt = LocalDateTime.now();
    }
}

