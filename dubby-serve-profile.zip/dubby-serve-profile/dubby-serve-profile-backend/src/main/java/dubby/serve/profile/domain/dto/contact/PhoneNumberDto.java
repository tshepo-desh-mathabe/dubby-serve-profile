package dubby.serve.profile.domain.dto.contact;

import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@NoArgsConstructor
public class PhoneNumberDto {

    private Long phoneNumberId;

    @NotBlank(message = EntityConstants.EMPTY_PHONE_NUMBER)
    private String number;

    @NotBlank(message = EntityConstants.EMPTY_COUNTRY_CODE)
    private CountryCodeDetailsDto countryCodeDetails;
}
