package dubby.serve.profile.util.property_fetcher;

import dubby.serve.profile.util.contants.AppConstant;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Implementation for property retrieval operator
 * Here we get a property and insert it in a field
 */
@Component
public class PropertyFetcherImpl implements IPropertyFetcher<AppConstant> {

    @Value("${app.jwt.bearer-text}")
    private String bearer;
    @Value("${app.jwt.authorization-text}")
    private String authorization;
    @Value("${app.jwt.secret}")
    private String jwtSecret;
    @Value("${app.jwt.expiration-time}")
    private String jwtExpirationTime;
    @Value("${error.message.email-format}")
    private String badEmailFormat;
    @Value("${error.message.email-exists}")
    private String emailExists;
    @Value("${error.message.phone-number-format}")
    private String badPhoneNumberFormat;
    @Value("${error.message.phone-number-exists}")
    private String phoneNumberExists;
    @Value("${training-vacancy.success-save.message}")
    private String successSaveVacancy;
    @Value("${training-vacancy.email-subject.message}")
    private String vacancyMailSubject;
    @Value("${error.message.went-wrong}")
    private String wentWrongMessage;
    @Value("${error.message.no-data}")
    private String noData;
    @Value("${error.message.no-document}")
    private String noDocuments;
    @Value("${error.message.no-country-code-details}")
    private String noCountryCodeDetailsDetails;
    @Value("${delete.success.message}")
    private String successDelete;
    @Value("${marked.read.message}")
    private String markedRead;
    @Value("${enquiry.success-save.message}")
    private String enquiryMade;
    @Value("${save.success.message}")
    private String saveSuccess;
    @Value("${error.message.unauthorized}")
    private String contactDetailsRequired;
    @Value("${error.message.user-sign-in}")
    private String badLoginCredentials;
    @Value("${app.content-type.online}")
    private String contentTypeOnline;
    @Value("${app.string.true}")
    private String trueString;
    @Value("${mail.smtp.auth}")
    private String mailAuth;
    @Value("${mail.smtp.host}")
    private String mailHost;
    @Value("${mail.smtp.port}")
    private String mailPort;
    @Value("${mail.smtp.port-number}")
    private String mailPortNumber;
    @Value("${mail.smtp.isp}")
    private String mailIsp;
    @Value("${mail.smtp.starttls.enable}")
    private String mailTlsEnable;
    @Value("${http.describe.head}")
    private String httpHead;
    @Value("${http.describe.options}")
    private String httpOptions;
    @Value("${http.describe.get}")
    private String httpGet;
    @Value("${http.describe.post}")
    private String httpPost;
    @Value("${http.describe.put}")
    private String httpPut;
    @Value("${http.describe.patch}")
    private String httpPatch;
    @Value("${http.describe.delete}")
    private String httpDelete;
    @Value("${fe.base.domain}")
    private String feBaseDomain;


    @Override
    public String getProperty(AppConstant keyValue) {
        return switch (keyValue) {
            case BEAR -> bearer;
            case AUTHORIZATION -> authorization;
            case JWT_SECRET -> jwtSecret;
            case JWT_EXPIRATION_TIME -> jwtExpirationTime;
            case BAD_EMAIL_FORMAT -> badEmailFormat;
            case EMAIL_EXISTS -> emailExists;
            case BAD_PHONE_NUMBER_FORMAT -> badPhoneNumberFormat;
            case PHONE_NUMBER_EXISTS -> phoneNumberExists;
            case SUCCESS_SAVE_VACANCY_MESSAGE -> successSaveVacancy;
            case EMAIL_SUBJECT_VACANCY_MESSAGE -> vacancyMailSubject;
            case WENT_WRONG_MESSAGE -> wentWrongMessage;
            case NO_DATA_MESSAGE -> noData;
            case NO_DOCUMENTS -> noDocuments;
            case NO_COUNTRY_CODE_DETAILS -> noCountryCodeDetailsDetails;
            case SUCCESS_DELETE_MESSAGE -> successDelete;
            case MARKED_READ_MESSAGE -> markedRead;
            case ENQUIRY_MADE_MESSAGE -> enquiryMade;
            case SAVE_SUCCESS_MESSAGE -> saveSuccess;
            case UNAUTHORIZED_MESSAGE -> contactDetailsRequired;
            case BAD_LOGIN_CREDENTIALS -> badLoginCredentials;
            case CONTENT_TYPE_ONLINE -> contentTypeOnline;
            case TRUE_STRING -> trueString;
            case EMAIL_AUTH -> mailAuth;
            case EMAIL_HOST -> mailHost;
            case EMAIL_PORT -> mailPort;
            case EMAIL_PORT_NUMBER -> mailPortNumber;
            case EMAIL_ISP -> mailIsp;
            case EMAIL_TLS_ENABLED -> mailTlsEnable;
            case HTTP_HEAD -> httpHead;
            case HTTP_OPTIONS -> httpOptions;
            case HTTP_GET -> httpGet;
            case HTTP_POST -> httpPost;
            case HTTP_PUT -> httpPut;
            case HTTP_PATCH -> httpPatch;
            case HTTP_DELETE -> httpDelete;
            case FE_BASE_DOMAIN -> feBaseDomain;
        };
    }
}