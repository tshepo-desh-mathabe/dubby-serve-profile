package dubby.serve.profile.domain.general;

import dubby.serve.profile.util.contants.EntityConstants;
import dubby.serve.profile.util.contants.TrainingVacancyType;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@NoArgsConstructor
@Table(name = EntityConstants.VACANCY_OPTION, uniqueConstraints = {
        @UniqueConstraint(columnNames = { EntityConstants.OPTION } )
})
public class VacancyOption {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = EntityConstants.VACANCY_OPTION_ID)
    private Long id;


    @Enumerated(EnumType.STRING)
    @Column(name = EntityConstants.OPTION, nullable = false, length = 10)
    private TrainingVacancyType vacancyOption;
}
