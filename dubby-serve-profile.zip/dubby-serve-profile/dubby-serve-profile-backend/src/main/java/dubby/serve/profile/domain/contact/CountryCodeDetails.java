package dubby.serve.profile.domain.contact;

import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

/**
 * Data should not be store in this table.
 * Only retrieve!!!
 */
@Data
@Entity
@NoArgsConstructor
@Table(name = EntityConstants.COUNTRY_CODE, uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                EntityConstants.COUNTRY_NAME_1, EntityConstants.COUNTRY_NAME_2,
                EntityConstants.ISO, EntityConstants.ISO_3
        })
})
public class CountryCodeDetails {

        @Id
        @Column(name = EntityConstants.COUNTRY_CODE_ID)
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @NotNull
        @Column(name = EntityConstants.ISO, columnDefinition="CHAR", length = 2)
        private String iso;

        @NotNull
        @Column(name = EntityConstants.COUNTRY_NAME_1, length = 60)
        private String countryName1;

        @NotNull
        @Column(name = EntityConstants.COUNTRY_NAME_2, length = 60)
        private String countryName2;

        @Column(name = EntityConstants.ISO_3, columnDefinition="CHAR", length = 3)
        private String iso3;

        @Column(name = EntityConstants.NUM_CODE, columnDefinition = "SMALLINT", length = 6)
        @Type(type = "org.hibernate.type.ShortType")
        private Short numCode;

        @NotNull
        @Column(name = EntityConstants.CODE, length = 5)
        private String code;

}
