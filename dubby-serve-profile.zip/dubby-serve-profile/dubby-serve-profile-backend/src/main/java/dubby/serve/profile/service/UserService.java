package dubby.serve.profile.service;

import dubby.serve.profile.domain.dto.general.UserDto;
import dubby.serve.profile.payload.LoggedInUserSummary;
import dubby.serve.profile.security.JwtTokenProvider;
import dubby.serve.profile.security.UserPrincipal;
import dubby.serve.profile.util.contants.AppConstant;
import dubby.serve.profile.util.property_fetcher.IPropertyFetcher;
import dubby.serve.profile.util.response.ResponseApiWrapper;
import dubby.serve.profile.util.validator.IValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private JwtTokenProvider tokenProvider;
    @Autowired
    private IValidator validator;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private IPropertyFetcher<AppConstant> propertyFetcher;

    public ResponseEntity<?> signIn(UserDto payload) {
        if (!validator.isValidEmailAddress(payload.getEmailAddressDetails().getEmailAddress())) {
            return ResponseApiWrapper.badRequest(AppConstant.BAD_EMAIL_FORMAT);
        }
        Authentication authentication = null;
        try {
            authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            payload.getEmailAddressDetails().getEmailAddress(),
                            payload.getPassword()
                    )
            );
        } catch (Exception ex) {
            return ResponseApiWrapper.badRequest(propertyFetcher.getProperty(AppConstant.BAD_LOGIN_CREDENTIALS));
        }

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwtToken = tokenProvider.generateToken(authentication);
        return ResponseApiWrapper.okRequest(getLoggedUser(jwtToken));
    }

    private LoggedInUserSummary getLoggedUser(String token) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication.getPrincipal() instanceof UserPrincipal principal) {
            return new LoggedInUserSummary(principal.name(), principal.surname(), token, authentication.getAuthorities());
        }
        return null;
    }

}
