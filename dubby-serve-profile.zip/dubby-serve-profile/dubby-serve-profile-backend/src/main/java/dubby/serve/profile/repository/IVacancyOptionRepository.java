package dubby.serve.profile.repository;

import dubby.serve.profile.domain.general.VacancyOption;
import dubby.serve.profile.util.contants.TrainingVacancyType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IVacancyOptionRepository extends CrudRepository<VacancyOption, Long> {

    Optional<VacancyOption> findByVacancyOption(TrainingVacancyType searchValue);
}
