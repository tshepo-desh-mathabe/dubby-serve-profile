package dubby.serve.profile.service.util.contact_details;

import dubby.serve.profile.domain.contact.EmailAddress;
import dubby.serve.profile.domain.dto.contact.EmailAddressDto;
import dubby.serve.profile.repository.IEmailAddressRepository;
import dubby.serve.profile.util.contants.AppConstant;
import dubby.serve.profile.util.helper.ICheck;
import dubby.serve.profile.util.helper.ICrudServiceApi;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.property_fetcher.IPropertyFetcher;
import dubby.serve.profile.util.response.ApiResponse;
import dubby.serve.profile.util.response.ApiResponseHelper;
import dubby.serve.profile.util.validator.IValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

/**
 * This bean does not PERSIST data
 */
@Component
public class EmailAddressServiceImpl implements ICrudServiceApi<EmailAddressDto>, ICheck<EmailAddress> {

    private static final Logger logger = LoggerFactory.getLogger(EmailAddressServiceImpl.class);

    @Autowired
    private IEmailAddressRepository emailAddressRepository;
    @Autowired
    private IPropertyFetcher<AppConstant> propertyFetcher;
    @Autowired
    private IModelMapper<EmailAddress, EmailAddressDto> mapper;
    @Autowired
    private IValidator validator;


    @Override
    public ApiResponse<?> checkData(EmailAddress data) {
        if (validator.isValidEmailAddress(data.getAddress())) {
            if (emailAddressRepository.existsByAddress(data.getAddress())) {
                return ApiResponseHelper.badResponse(propertyFetcher.getProperty(AppConstant.EMAIL_EXISTS));
            }
        } else {
            return ApiResponseHelper.badResponse(propertyFetcher.getProperty(AppConstant.BAD_EMAIL_FORMAT));
        }

        return ApiResponseHelper.okResponse(data);
    }

    @Override
    public ApiResponse<?> findWithString(String searchValue) {
        Optional<EmailAddress> emailAddress = emailAddressRepository.findByAddress(searchValue);

        try {
            if (emailAddress.isEmpty()) {
                return ApiResponseHelper.okResponse(propertyFetcher.getProperty(AppConstant.NO_DATA_MESSAGE));
            } else {
                return ApiResponseHelper.okResponse(mapper.toDto(emailAddress.get()));
            }
        } catch (Exception ex) {
            return ApiResponseHelper.badResponse(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
        }
    }

    @Override
    public ApiResponse<?> retrieveAll(Pageable pageable) {
        Set<EmailAddress> emailAddresses = new HashSet<>();
        emailAddressRepository.findAll().forEach(emailAddresses::add);

        try {
            if (!emailAddresses.isEmpty()) {
                Set<EmailAddressDto> data = mapper.toDto(emailAddresses);
                return ApiResponseHelper.okResponse(data);
            }
            return ApiResponseHelper.okResponse(propertyFetcher.getProperty(AppConstant.NO_DATA_MESSAGE));
        } catch (Exception ex) {
            logger.error("Get Via Pagination -->", ex);
            return ApiResponseHelper.badResponse(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
        }
    }
}
