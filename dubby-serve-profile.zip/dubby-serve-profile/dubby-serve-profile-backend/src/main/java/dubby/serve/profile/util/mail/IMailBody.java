package dubby.serve.profile.util.mail;

public interface IMailBody {

    default String htmlMessageBody(String fullName) {
        return null;
    }
}