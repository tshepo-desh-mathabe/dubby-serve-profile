package dubby.serve.profile.domain.contact;

import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Data
@Entity
@NoArgsConstructor
@Table(name = EntityConstants.PHONE_NUMBER, uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                EntityConstants.NUMBER
        })
})
public class PhoneNumber {

    @Id
    @Column(name = EntityConstants.PHONE_NUMBER_ID)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @OneToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = EntityConstants.COUNTRY_CODE_ID, referencedColumnName = EntityConstants.COUNTRY_CODE_ID)
    private CountryCodeDetails countryCodeDetails;

    @NotNull
    @Column(name = EntityConstants.NUMBER, length = 50)
    private String number;

}
