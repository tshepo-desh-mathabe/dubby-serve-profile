package dubby.serve.profile.util.helper;

import dubby.serve.profile.payload.ReadDeletePayload;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

/**
 * Helps with CRUD operations
 * @param <D> dto as the payload
 */
public interface ICrudServiceResponse<D> {

    ResponseEntity<?> save(D payload) throws Exception;

    ResponseEntity<?> getById(Long id) throws Exception;

    ResponseEntity<?> retrieveAll(Pageable pageable) throws Exception;

    ResponseEntity<?> deleteOneById(Long id) throws Exception;

    default ResponseEntity<?> deleteAll(Long[] ids) throws Exception {
        return null;
    }

    ResponseEntity<?> updateReadOrDelete(ReadDeletePayload readDeletePayload) throws Exception;
}
