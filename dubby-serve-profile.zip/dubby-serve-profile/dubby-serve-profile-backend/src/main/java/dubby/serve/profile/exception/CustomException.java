package dubby.serve.profile.exception;

import dubby.serve.profile.util.response.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.OK)
public class CustomException extends RuntimeException {
    private final ApiResponse resourceName;

    public CustomException(ApiResponse resourceName) {
        this.resourceName = resourceName;
    }
}