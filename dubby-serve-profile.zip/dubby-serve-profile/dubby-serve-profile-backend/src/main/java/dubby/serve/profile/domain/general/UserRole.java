package dubby.serve.profile.domain.general;

import dubby.serve.profile.util.contants.EntityConstants;
import dubby.serve.profile.util.contants.RoleType;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@NoArgsConstructor
@Table(name = EntityConstants.ROLE, uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                EntityConstants.NAME
        })
})
public class UserRole {

    @Id
    @Column(name = EntityConstants.ROLE_ID, length = 1)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = EntityConstants.NAME, nullable = false, length = 15)
    private RoleType roleType;
}