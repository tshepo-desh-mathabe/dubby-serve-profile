package dubby.serve.profile.service.util.contact_details;

import dubby.serve.profile.domain.contact.CountryCodeDetails;
import dubby.serve.profile.domain.dto.contact.CountryCodeDetailsDto;
import dubby.serve.profile.repository.ICountryCodeDetailsRepository;
import dubby.serve.profile.util.contants.AppConstant;
import dubby.serve.profile.util.helper.IFinder;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.property_fetcher.IPropertyFetcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class CountryCodeDetailsServiceImpl implements IFinder<CountryCodeDetailsDto> {

    private static final Logger logger = LoggerFactory.getLogger(CountryCodeDetailsServiceImpl.class);

    @Autowired
    private ICountryCodeDetailsRepository countryCodeRepository;
    @Autowired
    private IPropertyFetcher<AppConstant> propertyFetcher;
    @Autowired
    private IModelMapper<CountryCodeDetails, CountryCodeDetailsDto> mapper;

    @Override
    public CountryCodeDetailsDto findWithString(String searchValue) {
        String value = searchValue.substring(1);
        String data = value.replaceAll(" ","");

        Optional<CountryCodeDetails> countryCode = countryCodeRepository.findByCode(data);

        if (countryCode.isEmpty()) {
            return null;
        } else {
            return mapper.toDto(countryCode.get());
        }
    }
}
