package dubby.serve.profile.util.contants;

public enum TrainingVacancyType {
    VACANCY, TRAINING
}
