package dubby.serve.profile.util.mapper.contact;

import dubby.serve.profile.domain.contact.PhoneNumber;
import dubby.serve.profile.domain.dto.contact.PhoneNumberDto;
import dubby.serve.profile.util.helper.IFieldPropertyMapper;
import dubby.serve.profile.util.helper.IModelMapper;
import org.springframework.stereotype.Component;

@Component
public class PhoneNumberMapperImp implements IModelMapper<PhoneNumber, PhoneNumberDto> {

    @Override
    public PhoneNumber toEntity(PhoneNumberDto dto) {
        return convertToEntity(dto);
    }

    @Override
    public PhoneNumberDto toDto(PhoneNumber entity) {
        return convertToDto(entity);
    }

    private PhoneNumberDto convertToDto(PhoneNumber phoneNumber) {
        if (phoneNumber != null) {
            IFieldPropertyMapper<PhoneNumberDto> mapper = destination -> {
                destination.setPhoneNumberId(phoneNumber.getId());
                destination.setNumber(phoneNumber.getNumber());
                destination.setCountryCodeDetails(new CountryCodeMapperImpl().toDto(phoneNumber.getCountryCodeDetails()));

                return destination;
            };

            return mapper.mapTo(new PhoneNumberDto());
        } else {
            return null;
        }
    }

    private PhoneNumber convertToEntity(PhoneNumberDto phoneNumberDto) {
        if (phoneNumberDto != null) {
            IFieldPropertyMapper<PhoneNumber> mapper = destination -> {
                destination.setId(phoneNumberDto.getPhoneNumberId());
                destination.setNumber(phoneNumberDto.getNumber());
                destination.setCountryCodeDetails(new CountryCodeMapperImpl().toEntity(phoneNumberDto.getCountryCodeDetails()));

                return destination;
            };

            return mapper.mapTo(new PhoneNumber());
        } else {
            return null;
        }
    }
}
