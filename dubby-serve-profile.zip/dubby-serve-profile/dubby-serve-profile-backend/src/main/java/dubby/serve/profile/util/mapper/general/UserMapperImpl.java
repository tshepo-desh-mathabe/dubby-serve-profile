package dubby.serve.profile.util.mapper.general;

import dubby.serve.profile.domain.dto.general.UserDto;
import dubby.serve.profile.domain.general.User;
import dubby.serve.profile.util.helper.IFieldPropertyMapper;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.mapper.contact.EmailAddressMapperImpl;
import dubby.serve.profile.util.mapper.helper.ListMapperHelper;
import org.springframework.stereotype.Component;

@Component
public class UserMapperImpl extends ListMapperHelper<User, UserDto> implements IModelMapper<User, UserDto> {
    
    @Override
    public User toEntity(UserDto dto) {
        return convertToEntity(dto);
    }

    @Override
    public UserDto toDto(User entity) {
        return convertToDto(entity);
    }

    private UserDto convertToDto(User user) {
        if (user != null) {
            IFieldPropertyMapper<UserDto> mapper = destination -> {
                destination.setUserId(user.getId());
                destination.setName(user.getFirstName());
                destination.setSurname(user.getLastName());
                destination.setPassword(user.getPassword());
                destination.setEmailAddressDetails(new EmailAddressMapperImpl().toDto(user.getEmailAddress()));
                destination.setUserRoleDetails(new UserRoleMapperImpl().toDto(user.getRoles()));

                return destination;
            };

            return mapper.mapTo(new UserDto());
        } else {
            return null;
        }
    }

    private User convertToEntity(UserDto userDto) {
        if (userDto != null) {
            IFieldPropertyMapper<User> mapper = destination -> {
                destination.setId(userDto.getUserId());
                destination.setFirstName(userDto.getName());
                destination.setLastName(userDto.getSurname());
                destination.setPassword(userDto.getPassword());
                destination.setEmailAddress(new EmailAddressMapperImpl().toEntity(userDto.getEmailAddressDetails()));
                destination.setRoles(new UserRoleMapperImpl().toEntity(userDto.getUserRoleDetails()));

                return destination;
            };

            return mapper.mapTo(new User());
        } else {
            return null;
        }
    }
}
