package dubby.serve.profile.controller;

import dubby.serve.profile.domain.dto.general.EnquiryDto;
import dubby.serve.profile.payload.ReadDeletePayload;
import dubby.serve.profile.service.EnquiryService;
import dubby.serve.profile.util.contants.ServicePath;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(ServicePath.ENQUIRY_ENTRY_POINT)
public class EnquiryController {

    @Autowired
    private EnquiryService service;

    @PostMapping(ServicePath.SAVE)
    public Object saveData(@RequestBody EnquiryDto payload) throws Exception {
        return service.saveEnquiry(payload).getBody();
    }

    @GetMapping(ServicePath.GET_BY_ID)
    public ResponseEntity<?> retrieveById(@PathVariable Long id) throws Exception{
        return service.getEnquiryById(id);
    }

    @GetMapping(ServicePath.GET_ALL)
    public ResponseEntity<?> getAll(Pageable pageable) throws Exception {
        return service.getAllEnquiries(pageable);
    }

    @DeleteMapping(ServicePath.DELETE_BY_ID)
    public ResponseEntity<?> deleteById(@PathVariable Long id) throws Exception {
        return service.deleteEnquiryById(id);
    }

    @DeleteMapping(ServicePath.DELETE_ALL)
    public ResponseEntity<?> deleteAll(@RequestBody Long[] ids) throws Exception {
        return service.deleteAllEnquiries(ids);
    }

    @PutMapping(ServicePath.EDIT)
    public ResponseEntity<?> editReadOrDelete(@RequestBody ReadDeletePayload readDeletePayload) throws Exception {
        return service.editReadOrDeleteFromEnquiry(readDeletePayload);
    }

}

