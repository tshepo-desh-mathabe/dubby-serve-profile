package dubby.serve.profile.controller;

import dubby.serve.profile.domain.dto.general.UserDto;
import dubby.serve.profile.payload.LoggedInUserSummary;
import dubby.serve.profile.security.CurrentUser;
import dubby.serve.profile.security.UserPrincipal;
import dubby.serve.profile.service.UserService;
import dubby.serve.profile.util.contants.ServicePath;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping(ServicePath.USER_ENTRY_POINT)
public class UserController {

    @Autowired
    private UserService service;

    //    @PreAuthorize("hasRole('USER')")
    @GetMapping(ServicePath.GET_USER_LOGGED_IN)
    public LoggedInUserSummary getCurrentUser(@CurrentUser UserPrincipal currentUser) {
        return new LoggedInUserSummary(
                currentUser.name(), currentUser.surname(), currentUser.username(), currentUser.authorities()
        );
    }

    @PostMapping(ServicePath.USER_LOGIN)
    public Object authenticateUser(@Valid @RequestBody UserDto user) {
        return service.signIn(user).getBody();
    }

    @PostMapping(ServicePath.USER_LOGOUT)
    public void signOut(@CurrentUser UserPrincipal currentUser) {
        currentUser = null;
    }
}
