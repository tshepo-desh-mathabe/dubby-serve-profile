package dubby.serve.profile.util.response;

public class ApiResponseHelper {

    public static ApiResponse<?> okResponse(Object message) {
        return new ApiResponse(true, message);
    }

    public static ApiResponse<?> badResponse(Object message) {
        return new ApiResponse(false, message);
    }
}
