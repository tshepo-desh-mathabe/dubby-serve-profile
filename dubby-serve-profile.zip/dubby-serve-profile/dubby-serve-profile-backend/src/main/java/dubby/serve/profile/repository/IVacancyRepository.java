package dubby.serve.profile.repository;

import dubby.serve.profile.domain.general.Vacancy;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository

public interface IVacancyRepository extends PagingAndSortingRepository<Vacancy, Long> {
}
