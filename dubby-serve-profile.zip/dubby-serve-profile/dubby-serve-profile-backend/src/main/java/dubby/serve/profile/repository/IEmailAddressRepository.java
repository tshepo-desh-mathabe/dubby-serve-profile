package dubby.serve.profile.repository;

import dubby.serve.profile.domain.contact.EmailAddress;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IEmailAddressRepository extends CrudRepository<EmailAddress, Long> {

    Optional<EmailAddress> findByAddress(String address);

    Boolean existsByAddress(String emailAddress);
}
