package dubby.serve.profile.domain.dto.general;

import dubby.serve.profile.domain.dto.contact.ContactDetailsDto;
import dubby.serve.profile.domain.dto.helper.DateAuditDto;
import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
public class VacancyDto extends DateAuditDto {

    private Long vacancyId;

    @NotBlank(message = EntityConstants.EMPTY_FIRST_NAME_SUBJECT)
    private String name;

    @NotBlank(message = EntityConstants.EMPTY_LAST_NAME_SUBJECT)
    private String surname;

    @NotBlank(message = EntityConstants.EMPTY_MESSAGE)
    private String messageBody;

    @NotBlank(message = EntityConstants.EMPTY_TRAINING_VACANCY)
    private VacancyOptionDto vacancyOptionDetails;

    private ContactDetailsDto contactDetailsDetails;

    @NotBlank(message = EntityConstants.EMPTY_FILE)
    private Set<DocumentDto> documents;
}