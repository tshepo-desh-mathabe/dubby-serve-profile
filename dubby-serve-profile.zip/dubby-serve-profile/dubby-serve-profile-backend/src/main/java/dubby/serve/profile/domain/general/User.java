package dubby.serve.profile.domain.general;

import dubby.serve.profile.domain.contact.EmailAddress;
import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Set;

@Data
@Entity
@NoArgsConstructor
@Table(name = EntityConstants.USERS)
public class User {

    @Id
    @Column(name = EntityConstants.USER_ID)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

//    @NotNull
    @Column(name = EntityConstants.FIRST_NAME, length = 50)
    private String firstName;

//    @NotNull
    @Column(name = EntityConstants.LAST_NAME, length = 50)
    private String lastName;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = EntityConstants.EMAIL_ID, referencedColumnName = EntityConstants.EMAIL_ADDRESS_ID)
    private EmailAddress emailAddress;

    @NotNull
    @Column(name = EntityConstants.PASSWORD)
    private String password;

    @NotNull
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = EntityConstants.ROLE_USER,
            joinColumns = @JoinColumn(name = EntityConstants.USER_ID),
            inverseJoinColumns = @JoinColumn(name = EntityConstants.ROLE_ID)
    )
    private Set<UserRole> roles;
}
