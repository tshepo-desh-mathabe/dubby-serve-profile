package dubby.serve.profile.service.util;

import dubby.serve.profile.domain.dto.general.DocumentDto;
import dubby.serve.profile.domain.general.Document;
import dubby.serve.profile.exception.CustomException;
import dubby.serve.profile.repository.IDocumentRepository;
import dubby.serve.profile.util.contants.AppConstant;
import dubby.serve.profile.util.helper.ICrudServiceApi;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.property_fetcher.IPropertyFetcher;
import dubby.serve.profile.util.response.ApiResponse;
import dubby.serve.profile.util.response.ApiResponseHelper;
import dubby.serve.profile.util.response.ResponseApiWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.Set;

@Component
public class DocumentServiceImpl implements ICrudServiceApi<DocumentDto> {

    @Autowired
    private IDocumentRepository repository;
    @Autowired
    private IModelMapper<Document, DocumentDto> mapper;
    @Autowired
    private IPropertyFetcher<AppConstant> propertyFetcher;

    @Override
    public ApiResponse<?> save(Set<DocumentDto> payload) {
        try {
            if (payload.isEmpty()) {
//                throw new CustomException(ApiResponseHelper.badResponse(propertyFetcher.getProperty(AppConstant.NO_DOCUMENTS)));
                return ApiResponseHelper.badResponse(propertyFetcher.getProperty(AppConstant.NO_DOCUMENTS));
            }
            return ApiResponseHelper.okResponse(repository.saveAll(mapper.toEntity(payload)));
        } catch (Exception ex) {
            return ApiResponseHelper.badResponse(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
        }
    }

    @Override
    public ApiResponse<?> findWithId(Long id) {
        Optional<Document> document = repository.findById(id);

        if (!document.isEmpty()) {
            return ApiResponseHelper.okResponse(mapper.toDto(document.get()));
        } else {
            return null;
        }
    }
}
