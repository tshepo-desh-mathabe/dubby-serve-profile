package dubby.serve.profile.service.util;

import dubby.serve.profile.domain.dto.general.DocumentDto;
import dubby.serve.profile.domain.dto.general.VacancyDto;
import dubby.serve.profile.domain.dto.general.VacancyOptionDto;
import dubby.serve.profile.domain.general.Document;
import dubby.serve.profile.domain.general.Vacancy;
import dubby.serve.profile.payload.ReadDeletePayload;
import dubby.serve.profile.repository.IVacancyRepository;
import dubby.serve.profile.util.contants.AppConstant;
import dubby.serve.profile.util.contants.FlagHelper;
import dubby.serve.profile.util.helper.ICrudServiceApi;
import dubby.serve.profile.util.helper.ICrudServiceResponse;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.property_fetcher.IPropertyFetcher;
import dubby.serve.profile.util.response.ApiResponse;
import dubby.serve.profile.util.response.ResponseApiWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class VacancyServiceImpl implements ICrudServiceResponse<VacancyDto> {

    private final FlagHelper serviceFlag = FlagHelper.IS_VACANCY;
    @Autowired
    private IVacancyRepository repository;
    @Autowired
    private IModelMapper<Vacancy, VacancyDto> mapper;
    @Autowired
    private IPropertyFetcher<AppConstant> propertyFetcher;
    @Autowired
    private CrudHelper<Vacancy, VacancyDto> crudHelper;
    @Autowired
    private ICrudServiceApi<VacancyOptionDto> vacancyOptionService;
    @Autowired
    private ICrudServiceApi<DocumentDto> documentService;
    @Autowired
    private IModelMapper<Document, DocumentDto> documentMapper;

    @Override
    public ResponseEntity<?> save(VacancyDto payload) throws Exception {
        ApiResponse vacancyOptionResponse = vacancyOptionService.findWithString(payload.getVacancyOptionDetails().getVacancyOption());
        if (vacancyOptionResponse.getSuccess().equals(false)) {
            return ResponseApiWrapper.badRequest(vacancyOptionResponse.getMessage());
        } else payload.setVacancyOptionDetails((VacancyOptionDto) vacancyOptionResponse.getMessage());

        ApiResponse documentResponse = documentService.save(payload.getDocuments());
        if (documentResponse.getSuccess().equals(false)) {
            return ResponseApiWrapper.badRequest(documentResponse.getMessage());
        } else {
            List<Document> data = new ArrayList<>((Collection<? extends Document>) documentResponse.getMessage());
            Set<Document> documents = data.stream().collect(Collectors.toSet());
            Set<DocumentDto> documentDtos = documentMapper.toDto(documents);
            payload.setDocuments(documentDtos);
        }

        Vacancy vacancy = mapper.toEntity(payload);
        return crudHelper.saveData(vacancy, AppConstant.SUCCESS_SAVE_VACANCY_MESSAGE, repository);
    }

    @Override
    public ResponseEntity<?> getById(Long id) {
        ResponseEntity<?> response = crudHelper.retrieveOneById(serviceFlag, id, repository);

        if (!response.getStatusCode().equals(HttpStatus.BAD_REQUEST)) {
            if (response.getBody() instanceof Vacancy vacancy) {
                return ResponseApiWrapper.okRequest(mapper.toDto(vacancy));
            }
        }
        return response;
    }

    @Override
    public ResponseEntity<?> retrieveAll(Pageable pageable) {
        return crudHelper.getAllDataPagination(serviceFlag, pageable, repository);
    }

    @Override
    public ResponseEntity<?> deleteOneById(Long id) {
        return crudHelper.deleteObjectById(serviceFlag, id,repository);
    }

    @Override
    public ResponseEntity<?> deleteAll(Long[] ids) {
       return crudHelper.deleteAllByIds(serviceFlag, ids, repository);
    }

    @Override
    public ResponseEntity<?> updateReadOrDelete(ReadDeletePayload readDeletePayload) {
        return crudHelper.editAndSaveReadSoftDelete(serviceFlag, readDeletePayload, repository);
    }
}
