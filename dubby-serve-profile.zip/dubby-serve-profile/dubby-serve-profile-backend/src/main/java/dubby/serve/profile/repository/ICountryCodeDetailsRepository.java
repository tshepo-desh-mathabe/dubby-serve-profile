package dubby.serve.profile.repository;

import dubby.serve.profile.domain.contact.CountryCodeDetails;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ICountryCodeDetailsRepository extends CrudRepository<CountryCodeDetails, Long> {

    Optional<CountryCodeDetails> findByCode(String countryCode);
}
