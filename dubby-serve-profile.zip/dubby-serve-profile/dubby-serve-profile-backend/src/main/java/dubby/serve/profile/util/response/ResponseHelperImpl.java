package dubby.serve.profile.util.response;

import dubby.serve.profile.util.helper.IResponseHelper;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class ResponseHelperImpl implements IResponseHelper {

    public ResponseEntity<?> dataResponse(ApiResponse response) {
        if (response != null) {
            if (response.getSuccess()) {
                return ResponseApiWrapper.okRequest(response.getMessage());
            } else {
                return ResponseApiWrapper.badRequest(response.getMessage());
            }
        }

        return null;
    }
}
