package dubby.serve.profile.util.mapper.contact;

import dubby.serve.profile.domain.contact.CountryCodeDetails;
import dubby.serve.profile.domain.dto.contact.CountryCodeDetailsDto;
import dubby.serve.profile.util.helper.IFieldPropertyMapper;
import dubby.serve.profile.util.helper.IModelMapper;
import org.springframework.stereotype.Component;

@Component
public class CountryCodeMapperImpl implements IModelMapper<CountryCodeDetails, CountryCodeDetailsDto> {

    @Override
    public CountryCodeDetails toEntity(CountryCodeDetailsDto dto) {
        return convertToEntity(dto);
    }

    @Override
    public CountryCodeDetailsDto toDto(CountryCodeDetails entity) {
        return convertToDto(entity);
    }

    private CountryCodeDetailsDto convertToDto(CountryCodeDetails countryCodeDetails) {
        if (countryCodeDetails != null) {
            IFieldPropertyMapper<CountryCodeDetailsDto> mapper = destination -> {
                destination.setCountryCodeId(countryCodeDetails.getId());
                destination.setCountryIso(countryCodeDetails.getIso());
                destination.setCountryName1(countryCodeDetails.getCountryName1());
                destination.setCountryName2(countryCodeDetails.getCountryName2());
                destination.setCountryIso3(countryCodeDetails.getIso3());
                destination.setNumCode(countryCodeDetails.getNumCode());
                destination.setCode(countryCodeDetails.getCode());

                return destination;
            };

            return mapper.mapTo(new CountryCodeDetailsDto());
        } else {
            return null;
        }
    }

    private CountryCodeDetails convertToEntity(CountryCodeDetailsDto countryCodeDetailsDto) {
        if (countryCodeDetailsDto != null) {
            IFieldPropertyMapper<CountryCodeDetails> mapper = destination -> {destination.setId(countryCodeDetailsDto.getCountryCodeId());
                destination.setIso(countryCodeDetailsDto.getCountryIso());
                destination.setCountryName1(countryCodeDetailsDto.getCountryName1());
                destination.setCountryName2(countryCodeDetailsDto.getCountryName2());
                destination.setIso3(countryCodeDetailsDto.getCountryIso3());
                destination.setNumCode(countryCodeDetailsDto.getNumCode());
                destination.setCode(countryCodeDetailsDto.getCode());

                return destination;
            };

            return mapper.mapTo(new CountryCodeDetails());
        } else {
            return null;
        }
    }
}
