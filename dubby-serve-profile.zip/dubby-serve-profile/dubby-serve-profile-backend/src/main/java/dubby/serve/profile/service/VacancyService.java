package dubby.serve.profile.service;

import dubby.serve.profile.domain.dto.general.VacancyDto;
import dubby.serve.profile.payload.ReadDeletePayload;
import dubby.serve.profile.util.helper.ICrudServiceResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class VacancyService {
    
    @Autowired
    private ICrudServiceResponse<VacancyDto> service;

    @Transactional
    public ResponseEntity<?> saveVacancy(VacancyDto payload) throws Exception {
        return service.save(payload);
    }


    @Transactional(readOnly = true)
    public ResponseEntity<?> getVacancyById(Long id) throws Exception{
        return service.getById(id);
    }

    @Transactional(readOnly = true)
    public ResponseEntity<?> getAllVacancies(Pageable pageable) throws Exception {
        return service.retrieveAll(pageable);
    }

    @Transactional
    public ResponseEntity<?> deleteVacancyById(Long id) throws Exception {
        return service.deleteOneById(id);
    }

    @Transactional
    public ResponseEntity<?> deleteAllVacancies(Long[] ids) throws Exception {
        return service.deleteAll(ids);
    }

    @Transactional
    public ResponseEntity<?> editReadOrDeleteFromVacancy(ReadDeletePayload readDeletePayload) throws Exception {
        return service.updateReadOrDelete(readDeletePayload);
    }
}
