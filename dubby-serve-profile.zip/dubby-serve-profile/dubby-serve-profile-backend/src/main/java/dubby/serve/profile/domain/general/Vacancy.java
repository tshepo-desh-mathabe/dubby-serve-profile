package dubby.serve.profile.domain.general;

import dubby.serve.profile.domain.contact.ContactDetails;
import dubby.serve.profile.domain.helper.DateAudit;
import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Set;

@Data
@Entity
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Table(name = EntityConstants.VACANCY)
public class Vacancy extends DateAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = EntityConstants.VACANCY_ID)
    private Long id;

    @NotNull
    @Column(name = EntityConstants.FIRST_NAME, length = 50)
    private String firstName;

    @NotNull
    @Column(name = EntityConstants.LAST_NAME, length = 50)
    private String lastName;

    @NotNull
    @Column(name = EntityConstants.MESSAGE, length = 500)
    private String message;

    @OneToOne(cascade = CascadeType.MERGE)
    @NotNull(message = EntityConstants.NULL_VACANCY_OPTION_DETAILS)
    @JoinColumn(name = EntityConstants.VACANCY_OPTION_DETAILS, referencedColumnName = EntityConstants.VACANCY_OPTION_ID)
    private VacancyOption vacancyOption;

    @OneToOne(cascade = CascadeType.ALL)
    @NotNull(message = EntityConstants.NULL_CONTACT_DETAILS)
    @JoinColumn(name = EntityConstants.CONTACT_DETAILS, referencedColumnName = EntityConstants.CONTACT_ID)
    private ContactDetails contactDetails;

    @NotNull
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = EntityConstants.FILE,
            joinColumns = @JoinColumn(name = EntityConstants.VACANCY_ID),
            inverseJoinColumns = @JoinColumn(name = EntityConstants.DOCUMENT_ID)
    )
    private Set<Document> files;

}
