package dubby.serve.profile.util.configuration;

import dubby.serve.profile.util.contants.AppConstant;
import dubby.serve.profile.util.property_fetcher.IPropertyFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    @Autowired
    private IPropertyFetcher<AppConstant> propertyFetcher;

    private final long MAX_AGE_SECS = 3600;
    private final String feBaseDomain = "http://localhost:3000";

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins(propertyFetcher.getProperty(AppConstant.FE_BASE_DOMAIN))
                .allowedMethods(propertyFetcher.getProperty(AppConstant.HTTP_HEAD), "OPTIONS", "GET", "POST", "PUT", "PATCH", "DELETE")
                .maxAge(MAX_AGE_SECS);
    }
}
