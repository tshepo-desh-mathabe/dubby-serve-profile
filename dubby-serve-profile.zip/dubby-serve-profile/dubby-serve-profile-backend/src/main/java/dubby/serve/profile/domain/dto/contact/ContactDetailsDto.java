package dubby.serve.profile.domain.dto.contact;

import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@NoArgsConstructor
public class ContactDetailsDto {

    private Long contactDetailsId;
    @NotBlank(message = EntityConstants.NULL_PHONE_NUMBER)
    private PhoneNumberDto phoneNumberDetails;

    @NotBlank(message = EntityConstants.NULL_EMPTY_EMAIL_ADDRESS)
    private EmailAddressDto emailAddressDetails;
}