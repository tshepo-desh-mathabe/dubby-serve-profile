package dubby.serve.profile.repository;

import dubby.serve.profile.domain.contact.PhoneNumber;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IPhoneNumberRepository extends CrudRepository<PhoneNumber, Long> {

    Optional<PhoneNumber> findByNumber(String number);

    Boolean existsByNumber(String number);
}
