package dubby.serve.profile.domain.contact;

import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

@Data
@Entity
@NoArgsConstructor
@Table(name = EntityConstants.EMAIL_ADDRESS, uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                EntityConstants.EMAIL
        })
})
public class EmailAddress {

    @Id
    @Column(name = EntityConstants.EMAIL_ADDRESS_ID)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long emailId;

    @NotBlank
    @Column(name = EntityConstants.EMAIL, length = 150)
    private String address;
}
