package dubby.serve.profile.domain.general;

import dubby.serve.profile.domain.contact.ContactDetails;
import dubby.serve.profile.domain.helper.DateAudit;
import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Data
@Entity
@NoArgsConstructor
@Table(name = EntityConstants.ENQUIRY)
public class Enquiry extends DateAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = EntityConstants.ENQUIRY_ID)
    private Long id;

    @NotNull
    @Column(name = EntityConstants.FIRST_NAME, length = 50)
    private String firstName;

    @NotNull
    @Column(name = EntityConstants.LAST_NAME, length = 50)
    private String lastName;

    @NotNull
    @Column(name = EntityConstants.MESSAGE_SUBJECT, length = 50)
    private String subject;

    @NotNull
    @Column(name = EntityConstants.MESSAGE, length = 1000)
    private String message;

    @OneToOne(cascade = CascadeType.ALL)
    @NotNull(message = EntityConstants.NULL_CONTACT_DETAILS)
    @JoinColumn(name = EntityConstants.CONTACT_DETAILS, referencedColumnName = EntityConstants.CONTACT_ID)
    private ContactDetails contactDetails;

}


