package dubby.serve.profile.util.helper;

import dubby.serve.profile.util.response.ApiResponse;
import org.springframework.http.ResponseEntity;

@FunctionalInterface
public interface IResponseHelper {

    ResponseEntity<?> dataResponse(ApiResponse response);
}

