package dubby.serve.profile.util.contants;

public enum FlagHelper {
    SOFT_DELETE,
    IS_READ,
    IS_ENQUIRY,
    IS_VACANCY
}
