package dubby.serve.profile.repository;

import dubby.serve.profile.domain.contact.ContactDetails;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IContactDetailsRepository extends CrudRepository<ContactDetails, Long> {
}
