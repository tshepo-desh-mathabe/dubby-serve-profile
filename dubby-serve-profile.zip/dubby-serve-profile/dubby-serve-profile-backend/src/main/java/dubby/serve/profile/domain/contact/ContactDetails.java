package dubby.serve.profile.domain.contact;

import dubby.serve.profile.util.contants.EntityConstants;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Data
@Entity
@NoArgsConstructor
@Table(name = EntityConstants.CONTACT_DETAILS)
public class ContactDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = EntityConstants.CONTACT_ID)
    private Long contactId;

    @NotNull
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = EntityConstants.PHONE_NUMBER_ID, referencedColumnName = EntityConstants.PHONE_NUMBER_ID)
    private PhoneNumber phoneNumber;

    @NotNull
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = EntityConstants.EMAIL_ID, referencedColumnName = EntityConstants.EMAIL_ADDRESS_ID)
    private EmailAddress emailAddress;

}
