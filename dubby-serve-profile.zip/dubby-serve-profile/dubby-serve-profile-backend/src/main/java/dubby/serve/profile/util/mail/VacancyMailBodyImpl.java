package dubby.serve.profile.util.mail;

import dubby.serve.profile.domain.dto.general.VacancyDto;
import org.springframework.stereotype.Component;

@Component
public class VacancyMailBodyImpl implements IMailBody {

    @Override
    public String htmlMessageBody(String name) {
        return htmlMessage(name);
    }

    private String htmlMessage(String name) {
        return """
                <html>   
                <head>
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
                        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous" />
                </head>
                <body>
                    <b>
                        <div class="alert alert-warning" role="alert">
                            """
                            + message(name) +
                            """
                        </div>
                    </b>
                </body>
                </html>
                """;
    }

    private String message(String name) {
        return """
                Dear
                """
                + name +
                """ 
                <span style='font-size:25px;'>&#128029;</span>
                <br />
                <br />
                Your application has been recieved. <br/>
                Please bear with us, we will definitely get back to you soon.
                <br />
                <br />
                Warm Regards,
                <br />
                <b>Dubby Serve Team</b>
                """;
    }
}
