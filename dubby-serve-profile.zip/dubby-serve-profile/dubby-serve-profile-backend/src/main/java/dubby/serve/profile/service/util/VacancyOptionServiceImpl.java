package dubby.serve.profile.service.util;

import dubby.serve.profile.domain.dto.general.VacancyOptionDto;
import dubby.serve.profile.domain.general.VacancyOption;
import dubby.serve.profile.repository.IVacancyOptionRepository;
import dubby.serve.profile.util.contants.AppConstant;
import dubby.serve.profile.util.contants.TrainingVacancyType;
import dubby.serve.profile.util.helper.ICrudServiceApi;
import dubby.serve.profile.util.helper.IModelMapper;
import dubby.serve.profile.util.property_fetcher.IPropertyFetcher;
import dubby.serve.profile.util.response.ApiResponse;
import dubby.serve.profile.util.response.ApiResponseHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class VacancyOptionServiceImpl implements ICrudServiceApi<VacancyOptionDto> {
    @Autowired
    private IVacancyOptionRepository repository;
    @Autowired
    private IPropertyFetcher<AppConstant> propertyFetcher;
    @Autowired
    private IModelMapper<VacancyOption, VacancyOptionDto> mapper;

    @Override
    public ApiResponse<?> findWithString(String searchValue) {
        Optional<VacancyOption> option = repository.findByVacancyOption(TrainingVacancyType.valueOf(searchValue));
        if (option.isEmpty()) {
            return ApiResponseHelper.badResponse(propertyFetcher.getProperty(AppConstant.WENT_WRONG_MESSAGE));
        } else {
            return ApiResponseHelper.okResponse(mapper.toDto(option.get()));
        }
    }
}
