package dubby.serve.profile.repository;

import dubby.serve.profile.domain.general.UserRole;
import dubby.serve.profile.util.contants.RoleType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IUserRoleRepository extends CrudRepository<UserRole, Long> {

    Optional<UserRole> findByRoleType(RoleType type);
}
